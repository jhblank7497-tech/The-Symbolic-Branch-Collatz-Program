import Mathlib

/-!
# AdelicPlace3Unification — assembled single file (version 4)

Single standalone file (only `import Mathlib`), in five parts:
* Part 1, namespace `AdelicPlace3Unification`: the conservative conditional core
  (`PropertyA`, `PropertyB`, `PropertyC` and the three reduction theorems).
* Part 2, namespace `AdelicPlace3Unification.ToyModel`: `ToyModel.lean`.
* Part 3, namespace `AdelicPlace3Unification.ResidueLayer`: `ResidueLayer.lean`, Sections 1–9
  and the Fourier conjugation of `Pr_res`.
* Part 4, namespaces `AdelicPlace3Unification.FiniteTower` and `AdelicPlace3Unification.PadicTree`
  (Notes 9): towers of finite groups, the `p`-adic tree for any prime `p` (with `p = 3, 7`), a
  finite Euler product over a set of primes, and a two-place tensor family with a correlated
  prepared state.
* Part 5, namespace `AdelicPlace3Unification.AdelicSum` (new in version 4): convergence of the
  adelic sum over finite places for the test family `ψ_p = (zetaFactor s p - 1) • q0`
  (`adelic_sum_summable`, `C2_reduction`). This reduces interface C2; it does not prove it.

Status: NOT compiled. No Lean toolchain was available when this file was assembled; the code
was reviewed by reading only. Several Mathlib lemma names (for example `pow_eq_pow_mod`,
`Complex.exp_int_mul`, `Complex.mul_conj`, `Int.eq_zero_of_abs_lt_dvd`,
`Finset.card_biUnion`'s hypothesis form; in Part 4 `Complex.norm_natCast`, `Complex.norm_real`,
`inv_le_one_of_one_le₀`, `inv_lt_one_of_one_lt₀`, `ZMod.natCast_zmod_val`, `Nat.one_lt_pow`'s
argument form) are best-effort and may need adjusting to the pinned
Mathlib version. No placeholder proofs and no added axioms in this file.

Epistemic scope (unchanged from the core): nothing here identifies any operator with the
native Collatz/Syracuse transfer operator. Parts 2 and 3 show that the hypotheses of Part 1 are
satisfiable by explicit model operators (`P_toy`, `P_res`, `P_aff`, `P_walk`, and in Part 4 the
lazy tree walks and their tensor products); they do not prove them for `P_collatz`.

Corrections made while assembling (relative to the attached drafts):
1. Imports: the drafts' `import AdelicPlace3Unification` and the extra `Complex.Exp` import are
   dropped; `import Mathlib` covers everything.
2. Unfinished drafts removed: the first `card_modProj_fiber`, the first `char_add`, and the
   first `fourierSynth_intertwines_ρ` (each ended unfinished); the complete versions are kept.
3. `toy_satisfies_PropertyC` was declared `theorem`, but `PropertyC` carries data (`ρ`) and is
   not a `Prop`; it is now a `def`.
4. Fine level written `3 ^ (j + 1 + 1)` instead of `3 ^ (j + 2)` throughout Part 3, so that it
   matches `W (j + 1)` syntactically and `rw`/`simp` steps are not blocked.
5. `ZMod (3 ^ (j + 1))` is not syntactically `Fin`, so `⟨0, _⟩ : ZMod _` does not elaborate;
   the observable bound now uses `Pr_res j f 0`. A `NeZero (3 ^ n)` instance is declared.
6. `residue_end_to_end_reduction` passed implicit arguments positionally to
   `property_AB_imply_observable_convergence`; fixed.
7. Uses of `residue_satisfies_PropertyC.proj_intertwines` inside `rw` cannot match `ρ_res`;
   replaced by the standalone lemmas `ρ_res_Pr_res`, `ρ_res_q_res`, `Φ_res_ρ_res`.
8. Proofs that cannot work as written were rewritten: `P_toy_pow_apply` (rewrote under an
   unapplied function), `card_modProj_fiber_clean` (renamed `add_sub_cancel` lemmas replaced by
   `abel`; card of `univ`), linear-map axioms whose sums need `Finset.sum_congr`,
   `two_isUnit_zmod`, `char_add`, `sum_char_univ`, `liftPullback_char`, the `¬ 3 ∣ ξ` case of
   `ρ_res_char` (now by translation invariance of the fiber, `fiber_sum_shift`; the draft's
   3-element parametrization was cut off), `P_aff_pow_sub_Pr_res` and `P_walk_pow_sub_Pr_res`
   (a `set` variable blocked the rewrite), `fourierSynth_intertwines_ρ` (membership hypothesis
   taken from the wrong set), `fourierSynth_analysis`, `fourier_plancherel` and
   `fourierConj_Pr_res` (cut off in the draft).
9. `U_walk`: the drafts ran `induction` on `K.steps` (a projection) inside proofs; the walk is
   now defined through `walkSum` over an arbitrary list, with its linearity, Haar, decimation and
   norm properties proved once by list induction. Lemma names are kept.

Version 2 (from Notes 8):
10. `PropertyA` now asks for iterate convergence only at the prepared state `q j` (it takes `q`
    as a parameter), matching Definition A of the report. This weakens the hypothesis, so the
    core theorems become stronger. The model instances still prove convergence at every vector
    (`toy_iterate_tendsto`, `residue_iterate_tendsto`, `residue_affine_iterate_tendsto`,
    `residue_walk_iterate_tendsto`) and specialize it to `q j`.
11. New lemma `stationary_level_invariance`: `PropertyC` alone gives
    `Φ (j + d) (Pr (j + d) (q (j + d))) = Φ j (Pr j (q j))`. `property_BC_imply_rg_invariance`
    is now this lemma plus `PropertyB` at level `j + d` (the induction runs on the stationary
    data, as in Notes 8).
12. `combined_adelic_stationary_rg_reduction` takes Hypothesis 3 along an arbitrary filter `N` on
    an arbitrary index type `ι` (the report's neighbourhood filter `𝒩`); the argument order is
    unchanged, so the model instances (`ι = ℕ`, `N = atTop`) apply as before.
Not adopted from Notes 8: its bundled `AdelicLevelFamily` structure. The unbundled form is kept
so that `PropertyA`/`B`/`C` can be instantiated directly on `V` and `W` by the model instances;
the two forms state the same properties.

Version 3 (from Notes 9):
13. Part 4 added. The algebra common to all of Notes 9's models (point masses, Haar average,
    weighted total mass, fiber-sum decimation, the lazy walk `λ • id + (1 - λ) • avg`) is proved
    once, in `FiniteTower`, for any tower of finite additive groups with surjective
    homomorphisms `G (j + 1) →+ G j`; `tower_PropertyA`/`B`/`C` instantiate Part 1 for every
    such tower. The notes repeated the same proofs in five separate files.
14. `PadicTree`: the `p`-adic tree `ZMod (p ^ j)` for any prime `p` (`tree_PropertyA`/`B`/`C`),
    with the depth-uniform bound `tree_iterate_bound : ‖P^n q - Pr q‖ ≤ λ ^ n` and the
    specializations `p = 3` and `p = 7` (rates `1/2` and `1/p`). The notes' first instance
    (`P = Pr`) is the case `λ = 0` (`lazy_zero_apply`).
15. Finite Euler product over a finite set `S` of primes (`euler_combined_reduction`): here
    Hypothesis 3 of `combined_adelic_stationary_rg_reduction` is proved, not assumed. The limit
    is the product of the chosen weights; `euler_3_7_zeta2` evaluates it to `147/128` for the
    local factors `(1 - p⁻²)⁻¹` at `p = 3, 7`. This is a finite product of two chosen constants,
    not a statement about `ζ(2)`.
16. Two-place family on `ZMod (p ^ j) × ZMod (r ^ j)` with the Kronecker product of the lazy
    walks (`pairWalk`), the product Haar average (`tensorEndo_avg_avg`), factorization of the
    observable on the product state (`pair_obs_factorization`), and a correlated prepared state
    `corrState` that is provably not a pure tensor (`corrState_not_pure`) yet satisfies
    `PropertyA`/`B`/`C` (`corr_PropertyA`/`B`/`C`).
17. Corrections to the Notes 9 code: the filter-sum notation `∑ b with P b, f b` is replaced by
    an explicit `Finset.filter`; the bundled structure and its re-declarations in each file are
    dropped; level-dependent weights `w p j` with `w p (j + 1) = w p j` are replaced by
    level-independent weights `w p` (the hypothesis forces this); the complex power `p ^ (-s)` in
    the zeta factor is replaced by `((p : ℂ) ^ s)⁻¹` with `s : ℕ`, so that the check at `s = 2`
    is a `norm_num` computation; `rw [pow_succ']` steps name the operator being expanded, since
    the goals also contain powers of the rate; the notes' name "entangled" is replaced by
    "correlated" (the Lean statement is non-separability, nothing more).
Not formalized from Notes 9: its prose on Bruhat–Tits trees, the Vladimirov heat kernel and
Perron–Frobenius. The Lean model is the lazy walk only; its gap `1 - λ` is put in by
construction.
-/

open Filter Topology

namespace AdelicPlace3Unification

/-! # Part 1: Conservative conditional core
A conservative, conditional core extracted from Review 2.
No native Syracuse identification, character basis, or spectral theorem is claimed yet.
This file has not been compiled against Mathlib.

Review correction: the stationary projection family was named `Π`. Lean 4 does not accept `Π`
(or `Σ`, or `λ`) as an identifier, so every declaration that used it failed to parse; it is
renamed `Pr` throughout. No other change: the statements and proofs are otherwise as in the
reviewed file.

What is proved here, all conditionally on the hypotheses `PropertyA`, `PropertyB`, `PropertyC`:
* `stationary_level_invariance` (from `PropertyC` alone):
  `Φ (j + d) (Pr (j + d) (q (j + d))) = Φ j (Pr j (q j))`.
* `property_BC_imply_rg_invariance`: `smear3 (j + d) = Φ j (Pr j (q j))` for all `d`
  (the sequence `smear3` is constant from every level `j` on).
* `property_AB_imply_observable_convergence`: `Φ j (P j ^ n (q j)) → smear3 j` as `n → ∞`.
* `combined_adelic_stationary_rg_reduction`: a limit along any filter, stated with
  `smear3 (j + d)`, can be restated with `Φ j (Pr j (q j))`.
Nothing here verifies the hypotheses for the Collatz operator `P_collatz`; `PropertyC` carries
data (the maps `ρ`), so it is a structure in `Type`, not a `Prop`.
-/

variable (V : ℕ → Type*)
variable [∀ j, NormedAddCommGroup (V j)]
variable [∀ j, NormedSpace ℂ (V j)]

abbrev OperatorFamily := ∀ j, V j →ₗ[ℂ] V j
abbrev FunctionalFamily := ∀ j, V j →ₗ[ℂ] ℂ
abbrev StateFamily := ∀ j, V j

/-- `PropertyA` (Notes 8): iterate convergence is required only at the prepared state `q j`,
as in Definition A of the report; earlier versions required it at every vector. -/
structure PropertyA (P Pr : OperatorFamily V) (Φ : FunctionalFamily V) (q : StateFamily V) :
    Prop where
  operator_tendsto : ∀ j,
    Tendsto (fun n : ℕ => ‖((P j) ^ n) (q j) - (Pr j) (q j)‖) atTop (nhds 0)
  observable_bound : ∀ j, ∃ C : ℝ, 0 ≤ C ∧
    ∀ x : V j, ‖(Φ j) x‖ ≤ C * ‖x‖

structure PropertyB (smear3 : ℕ → ℂ) (Pr : OperatorFamily V)
    (Φ : FunctionalFamily V) (q : StateFamily V) : Prop where
  smear_eval : ∀ j, smear3 j = (Φ j) (q j)
  factors : ∀ j, (Φ j) (q j) = (Φ j) ((Pr j) (q j))

structure PropertyC (Pr : OperatorFamily V)
    (Φ : FunctionalFamily V) (q : StateFamily V) where
  ρ : ∀ j, V (j + 1) →ₗ[ℂ] V j
  proj_intertwines : ∀ j (x : V (j + 1)),
    ρ j ((Pr (j + 1)) x) = (Pr j) (ρ j x)
  state_compatible : ∀ j, ρ j (q (j + 1)) = q j
  functional_compatible : ∀ j (x : V (j + 1)),
    (Φ (j + 1)) x = (Φ j) (ρ j x)

lemma stationary_representation
    {smear3 : ℕ → ℂ} {Pr : OperatorFamily V}
    {Φ : FunctionalFamily V} {q : StateFamily V}
    (hB : PropertyB V smear3 Pr Φ q) (j : ℕ) :
    smear3 j = (Φ j) ((Pr j) (q j)) := by
  exact (hB.smear_eval j).trans (hB.factors j)

lemma stationary_step
    {Pr : OperatorFamily V} {Φ : FunctionalFamily V}
    {q : StateFamily V} (hC : PropertyC V Pr Φ q) (j : ℕ) :
    (Φ (j + 1)) ((Pr (j + 1)) (q (j + 1))) =
      (Φ j) ((Pr j) (q j)) := by
  calc
    (Φ (j + 1)) ((Pr (j + 1)) (q (j + 1))) =
        (Φ j) (hC.ρ j ((Pr (j + 1)) (q (j + 1)))) :=
      hC.functional_compatible j _
    _ = (Φ j) ((Pr j) (hC.ρ j (q (j + 1)))) := by
      rw [hC.proj_intertwines j (q (j + 1))]
    _ = (Φ j) ((Pr j) (q j)) := by
      rw [hC.state_compatible j]

/-- Level invariance of the stationary data from `PropertyC` alone (Notes 8): the value
`Φ j (Pr j (q j))` does not depend on the level. `PropertyB` is not used. -/
lemma stationary_level_invariance
    {Pr : OperatorFamily V} {Φ : FunctionalFamily V} {q : StateFamily V}
    (hC : PropertyC V Pr Φ q) (j d : ℕ) :
    (Φ (j + d)) ((Pr (j + d)) (q (j + d))) = (Φ j) ((Pr j) (q j)) := by
  induction d with
  | zero => rfl
  | succ d ih =>
    show (Φ (j + d + 1)) ((Pr (j + d + 1)) (q (j + d + 1))) = (Φ j) ((Pr j) (q j))
    rw [stationary_step V hC (j + d), ih]

theorem property_BC_imply_rg_invariance
    {smear3 : ℕ → ℂ} {Pr : OperatorFamily V}
    {Φ : FunctionalFamily V} {q : StateFamily V}
    (hB : PropertyB V smear3 Pr Φ q)
    (hC : PropertyC V Pr Φ q) (j d : ℕ) :
    smear3 (j + d) = (Φ j) ((Pr j) (q j)) := by
  rw [stationary_representation V hB (j + d)]
  exact stationary_level_invariance V hC j d

theorem property_AB_imply_observable_convergence
    {smear3 : ℕ → ℂ} {P Pr : OperatorFamily V}
    {Φ : FunctionalFamily V} {q : StateFamily V}
    (hA : PropertyA V P Pr Φ q)
    (hB : PropertyB V smear3 Pr Φ q) (j : ℕ) :
    Tendsto (fun n : ℕ => (Φ j) (((P j) ^ n) (q j)))
      atTop (nhds (smear3 j)) := by
  rw [stationary_representation V hB j]
  rw [tendsto_iff_norm_sub_tendsto_zero]
  obtain ⟨C, _, hBound⟩ := hA.observable_bound j
  have hUpper : Tendsto
      (fun n : ℕ => C * ‖((P j) ^ n) (q j) - (Pr j) (q j)‖)
      atTop (nhds 0) := by
    convert (hA.operator_tendsto j).const_mul C using 1 <;> simp
  apply squeeze_zero
  · intro n
    exact norm_nonneg _
  · intro n
    rw [← map_sub]
    exact hBound _
  · exact hUpper

/-- Hypothesis 3 is stated for an arbitrary filter `N` on an arbitrary index type `ι` (Notes 8),
matching the neighbourhood filter `𝒩` of the report; `atTop` on `ℕ` is the special case used by
the model instances. -/
theorem combined_adelic_stationary_rg_reduction
    {ι : Type*} (restrictedSmear : ι → ℂ) (smear3 : ℕ → ℂ) (spectatorProd : ℂ)
    {N : Filter ι}
    {Pr : OperatorFamily V} {Φ : FunctionalFamily V}
    {q : StateFamily V}
    (hB : PropertyB V smear3 Pr Φ q)
    (hC : PropertyC V Pr Φ q)
    (j d : ℕ)
    (h_hyp3 : Tendsto restrictedSmear N
      (nhds (smear3 (j + d) * spectatorProd))) :
    Tendsto restrictedSmear N
      (nhds ((Φ j) ((Pr j) (q j)) * spectatorProd)) := by
  rw [property_BC_imply_rg_invariance V hB hC j d] at h_hyp3
  exact h_hyp3

end AdelicPlace3Unification

/-! # Part 2: Finite-Dimensional Spectral Toy Model (from `ToyModel.lean`)

Constructs an explicit diagonalizable toy model on `V j := Fin (period j) → ℂ` with Mathlib's
sup-norm and discharges `PropertyA`, `PropertyB` and `PropertyC`, showing that the hypotheses of
Part 1 are satisfiable.

Epistemic boundary: this models the spectral and decimation mechanics in eigenmode coordinates
(`Fin (period j) → ℂ`). It does NOT claim an isomorphism with the native Collatz/Syracuse
operator on `ZMod (3 ^ j)`.
-/

namespace AdelicPlace3Unification.ToyModel

/-- Dimension `period j`: `1` at `j = 0`, and `2 * 3 ^ (j - 1)` for `j ≥ 1`. -/
def period : ℕ → ℕ
  | 0 => 1
  | j + 1 => 2 * 3 ^ j

lemma period_pos (j : ℕ) : 0 < period j := by
  cases j with
  | zero => decide
  | succ j =>
    unfold period
    positivity

lemma period_mono (j : ℕ) : period j ≤ period (j + 1) := by
  cases j with
  | zero =>
    change 1 ≤ 2 * 3 ^ 0
    norm_num
  | succ j =>
    change 2 * 3 ^ j ≤ 2 * 3 ^ (j + 1)
    have hpow : 3 ^ j ≤ 3 ^ (j + 1) := Nat.pow_le_pow_right (by decide) (Nat.le_succ j)
    omega

/-- Finite-dimensional toy state space `V j := Fin (period j) → ℂ` (sup-norm from Mathlib). -/
abbrev V (j : ℕ) : Type := Fin (period j) → ℂ

/-- Toy transition operator: fixes `k = 0` and contracts all `k ≠ 0` by `1 / 2`. -/
def P_toy (j : ℕ) : V j →ₗ[ℂ] V j where
  toFun x k := if k.val = 0 then x k else (1 / 2 : ℂ) * x k
  map_add' x y := by
    ext k
    by_cases hk : k.val = 0 <;> simp [hk, mul_add]
  map_smul' c x := by
    ext k
    by_cases hk : k.val = 0 <;> simp [hk] <;> ring

lemma P_toy_apply (j : ℕ) (x : V j) (k : Fin (period j)) :
    P_toy j x k = if k.val = 0 then x k else (1 / 2 : ℂ) * x k := rfl

/-- Stationary map: retains `k = 0` and zeroes out all `k ≠ 0`. -/
def Pr_toy (j : ℕ) : V j →ₗ[ℂ] V j where
  toFun x k := if k.val = 0 then x k else 0
  map_add' x y := by
    ext k
    by_cases hk : k.val = 0 <;> simp [hk]
  map_smul' c x := by
    ext k
    by_cases hk : k.val = 0 <;> simp [hk]

/-- Observable functional extracting the stationary `k = 0` mode. -/
def Φ_toy (j : ℕ) : V j →ₗ[ℂ] ℂ where
  toFun x := x ⟨0, period_pos j⟩
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

/-- Prepared state with stationary component `1` and modes `1 / (k + 1)`. -/
def q_toy (j : ℕ) : V j :=
  fun k => if k.val = 0 then 1 else (1 : ℂ) / ((k.val : ℂ) + 1)

/-- Constant toy place-3 smear sequence `smear3_toy j = 1`. -/
def smear3_toy (_j : ℕ) : ℂ := 1

lemma P_toy_pow_apply (j n : ℕ) (x : V j) (k : Fin (period j)) :
    ((P_toy j) ^ n) x k = if k.val = 0 then x k else (1 / 2 : ℂ) ^ n * x k := by
  induction n generalizing x with
  | zero =>
    by_cases hk : k.val = 0 <;> simp [hk]
  | succ m ihm =>
    rw [pow_succ', LinearMap.mul_apply, P_toy_apply, ihm]
    by_cases hk : k.val = 0
    · simp [hk]
    · simp only [hk, ↓reduceIte]
      ring

lemma norm_P_toy_pow_sub_Pr_toy (j n : ℕ) (x : V j) :
    ‖((P_toy j) ^ n) x - (Pr_toy j) x‖ ≤ (1 / 2 : ℝ) ^ n * ‖x‖ := by
  rw [pi_norm_le_iff_of_nonneg (by positivity)]
  intro k
  simp only [Pi.sub_apply, P_toy_pow_apply, Pr_toy, LinearMap.coe_mk, AddHom.coe_mk]
  by_cases hk : k.val = 0
  · simp only [hk, ↓reduceIte, sub_self, norm_zero]
    positivity
  · simp only [hk, ↓reduceIte, sub_zero, norm_mul, norm_pow]
    have hhalf : ‖(1 / 2 : ℂ)‖ = (1 / 2 : ℝ) := by norm_num
    rw [hhalf]
    exact mul_le_mul_of_nonneg_left (norm_le_pi_norm x k) (by positivity)

/-- Iterate convergence at every vector (stronger than `PropertyA` needs). -/
lemma toy_iterate_tendsto (j : ℕ) (x : V j) :
    Tendsto (fun n : ℕ => ‖((P_toy j) ^ n) x - (Pr_toy j) x‖) atTop (nhds 0) := by
    have hHalf : Tendsto (fun n : ℕ => (1 / 2 : ℝ) ^ n) atTop (nhds 0) :=
      tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num)
    have hUpper : Tendsto (fun n : ℕ => (1 / 2 : ℝ) ^ n * ‖x‖) atTop (nhds 0) := by
      simpa only [zero_mul] using hHalf.mul_const ‖x‖
    apply squeeze_zero
    · intro n
      exact norm_nonneg _
    · intro n
      exact norm_P_toy_pow_sub_Pr_toy j n x
    · exact hUpper

theorem toy_satisfies_PropertyA :
    PropertyA V P_toy Pr_toy Φ_toy q_toy where
  operator_tendsto j := toy_iterate_tendsto j (q_toy j)
  observable_bound j := by
    refine ⟨1, zero_le_one, fun x => ?_⟩
    rw [one_mul]
    exact norm_le_pi_norm x ⟨0, period_pos j⟩

theorem toy_satisfies_PropertyB :
    PropertyB V smear3_toy Pr_toy Φ_toy q_toy where
  smear_eval j := by
    simp [smear3_toy, Φ_toy, q_toy]
  factors j := by
    simp [Φ_toy, Pr_toy, q_toy]

/-- Block-spin decimation onto the leading `period j` coordinates. -/
def ρ_toy (j : ℕ) : V (j + 1) →ₗ[ℂ] V j where
  toFun x k := x (Fin.castLE (period_mono j) k)
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

/-- `PropertyC` carries data (the maps `ρ`), so this is a `def`, not a `theorem`. -/
def toy_satisfies_PropertyC :
    PropertyC V Pr_toy Φ_toy q_toy where
  ρ := ρ_toy
  proj_intertwines j x := by
    ext k
    simp [ρ_toy, Pr_toy]
  state_compatible j := by
    ext k
    simp [ρ_toy, q_toy]
  functional_compatible j x := by
    rfl

theorem toy_combined_adelic_reduction
    (restrictedSmear : ℕ → ℂ) (spectatorProd : ℂ) (j d : ℕ)
    (h_hyp3 : Tendsto restrictedSmear atTop
      (nhds (smear3_toy (j + d) * spectatorProd))) :
    Tendsto restrictedSmear atTop
      (nhds ((Φ_toy j) ((Pr_toy j) (q_toy j)) * spectatorProd)) :=
  combined_adelic_stationary_rg_reduction
    V restrictedSmear smear3_toy spectatorProd
    toy_satisfies_PropertyB toy_satisfies_PropertyC j d h_hyp3

end AdelicPlace3Unification.ToyModel

/-! # Part 3: Residue-Class Layer on `W j := ZMod (3 ^ (j + 1)) → ℂ` (from `ResidueLayer.lean`)

Connects adjacent residue-class spaces through the canonical projection
`modProj j : ZMod (3 ^ (j + 1 + 1)) →+* ZMod (3 ^ (j + 1))` and builds:
* fiber-averaging decimation `ρ_res`, Haar average `Pr_res`, observable `Φ_res`, state `q_res`,
  discharging `PropertyB` and `PropertyC` (Section 1–2);
* the lazy walk `P_res`, discharging `PropertyA` (Section 3–4);
* the affine Koopman shift `x ↦ 2x + 1` and `P_aff` (Section 5);
* general affine step ensembles and convex walks `U_walk`, `P_walk` (Section 6);
* additive characters, their eigenvalue and decimation identities (Sections 7–8);
* discrete Fourier inversion, `fourierEquiv`, Plancherel, and transport of `Pr_res` (Section 9).

Epistemic boundary: `P_res`, `P_aff` and `P_walk` are model operators built so that the
hypotheses hold; none of them is the native Collatz/Syracuse transfer operator, and no statement
here identifies them with it. Throughout, the fine level is written `3 ^ (j + 1 + 1)` (not
`3 ^ (j + 2)`), so that it matches `W (j + 1)` syntactically and rewriting is not blocked.
-/

namespace AdelicPlace3Unification.ResidueLayer

instance instNeZeroThreePow (n : ℕ) : NeZero (3 ^ n) := ⟨pow_ne_zero n (by norm_num)⟩

/-- Residue-class function space at level `j` (modulus `3 ^ (j + 1)`), with the sup-norm. -/
abbrev W (j : ℕ) : Type := ZMod (3 ^ (j + 1)) → ℂ

lemma three_pow_dvd_succ (j : ℕ) : 3 ^ (j + 1) ∣ 3 ^ (j + 1 + 1) :=
  pow_dvd_pow 3 (Nat.le_succ (j + 1))

/-- Canonical modular projection `ZMod (3 ^ (j + 1 + 1)) →+* ZMod (3 ^ (j + 1))`. -/
def modProj (j : ℕ) : ZMod (3 ^ (j + 1 + 1)) →+* ZMod (3 ^ (j + 1)) :=
  ZMod.castHom (three_pow_dvd_succ j) (ZMod (3 ^ (j + 1)))

lemma modProj_surjective (j : ℕ) : Function.Surjective (modProj j) :=
  ZMod.castHom_surjective (three_pow_dvd_succ j)

/-- `modProj j` kills `3 ^ (j + 1)`. -/
lemma modProj_three_pow (j : ℕ) :
    modProj j ((3 ^ (j + 1) : ℕ) : ZMod (3 ^ (j + 1 + 1))) = 0 := by
  rw [modProj, ZMod.castHom_apply, ZMod.cast_natCast (three_pow_dvd_succ j), ZMod.natCast_self]

/-- Pullback lifting map `W j →ₗ[ℂ] W (j + 1)` along `modProj j`. -/
def liftPullback (j : ℕ) : W j →ₗ[ℂ] W (j + 1) where
  toFun f y := f (modProj j y)
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

/-! ## 1. Fiber cardinality and block-spin decimation `ρ_res j` -/

/-- Every fiber of `modProj j` has exactly `3` elements. (The request's first draft of this
lemma was unfinished; only the complete version is kept, under its original name.) -/
lemma card_modProj_fiber_clean (j : ℕ) (x : ZMod (3 ^ (j + 1))) :
    (Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x)).card = 3 := by
  have h_all_eq : ∀ a b : ZMod (3 ^ (j + 1)),
      (Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = a)).card =
      (Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = b)).card := by
    intro a b
    obtain ⟨y₀, hy₀⟩ := modProj_surjective j (b - a)
    refine Finset.card_bij (fun y _ => y + y₀) ?_ ?_ ?_
    · intro y hy
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hy ⊢
      rw [map_add, hy, hy₀]
      abel
    · intro y₁ _ y₂ _ h_eq
      exact add_right_cancel h_eq
    · intro z hz
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hz
      refine ⟨z - y₀, ?_, sub_add_cancel z y₀⟩
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      rw [map_sub, hz, hy₀]
      abel
  have h_sum :
      ∑ a : ZMod (3 ^ (j + 1)),
        (Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = a)).card =
      Fintype.card (ZMod (3 ^ (j + 1 + 1))) := by
    rw [← Finset.card_univ, ← Finset.card_biUnion]
    · congr 1
      ext y
      simp
    · intro a _ b _ hab
      change Disjoint _ _
      rw [Finset.disjoint_left]
      intro y hya hyb
      simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hya hyb
      exact hab (hya.symm.trans hyb)
  rw [Finset.sum_congr rfl (fun a _ => h_all_eq a x), Finset.sum_const, Finset.card_univ,
    ZMod.card, ZMod.card, smul_eq_mul] at h_sum
  have h_pow : 3 ^ (j + 1 + 1) = 3 ^ (j + 1) * 3 := by ring
  rw [h_pow] at h_sum
  exact Nat.eq_of_mul_eq_mul_left (by positivity : 0 < 3 ^ (j + 1)) h_sum

/-- Block-spin decimation `ρ_res j : W (j + 1) →ₗ[ℂ] W j`: average over the 3-element fiber. -/
noncomputable def ρ_res (j : ℕ) : W (j + 1) →ₗ[ℂ] W j where
  toFun f x :=
    (1 / 3 : ℂ) * ∑ y ∈ Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x), f y
  map_add' f g := by
    ext x
    simp only [Pi.add_apply]
    rw [Finset.sum_add_distrib, mul_add]
  map_smul' c f := by
    ext x
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    exact Finset.sum_congr rfl fun y _ => by ring

/-- Left-inverse property: `ρ_res j ∘ liftPullback j = id`. -/
lemma ρ_res_liftPullback (j : ℕ) (f : W j) :
    ρ_res j (liftPullback j f) = f := by
  ext x
  unfold ρ_res liftPullback
  simp only [LinearMap.coe_mk, AddHom.coe_mk]
  have h_const :
      ∑ y ∈ Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x),
        f (modProj j y) =
      ∑ _y ∈ Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x), f x := by
    refine Finset.sum_congr rfl fun y hy => ?_
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hy
    rw [hy]
  rw [h_const, Finset.sum_const, card_modProj_fiber_clean j x, nsmul_eq_mul]
  push_cast
  ring

/-! ## 2. Stationary projection, observable, prepared state; `PropertyB` and `PropertyC` -/

/-- Uniform stationary projection (Haar average) `Pr_res j : W j →ₗ[ℂ] W j`. -/
noncomputable def Pr_res (j : ℕ) : W j →ₗ[ℂ] W j where
  toFun f _x := (1 / ((3 : ℂ) ^ (j + 1))) * ∑ y : ZMod (3 ^ (j + 1)), f y
  map_add' f g := by
    ext x
    simp only [Pi.add_apply]
    rw [Finset.sum_add_distrib, mul_add]
  map_smul' c f := by
    ext x
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    exact Finset.sum_congr rfl fun y _ => by ring

/-- Uniform observable functional `Φ_res j : W j →ₗ[ℂ] ℂ` (the Haar mean). -/
noncomputable def Φ_res (j : ℕ) : W j →ₗ[ℂ] ℂ where
  toFun f := (1 / ((3 : ℂ) ^ (j + 1))) * ∑ y : ZMod (3 ^ (j + 1)), f y
  map_add' f g := by
    simp only [Pi.add_apply]
    rw [Finset.sum_add_distrib, mul_add]
  map_smul' c f := by
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    exact Finset.sum_congr rfl fun y _ => by ring

/-- Prepared constant unit state `q_res j x = 1`. -/
def q_res (j : ℕ) : W j := fun _ => 1

/-- Constant residue-layer smear sequence `smear3_res j = 1`. -/
def smear3_res (_j : ℕ) : ℂ := 1

/-- Summing over the fine ring factors through the fibers of `modProj j`. -/
lemma sum_univ_eq_sum_fibers (j : ℕ) (f : W (j + 1)) :
    ∑ y : ZMod (3 ^ (j + 1 + 1)), f y =
      ∑ x : ZMod (3 ^ (j + 1)),
        ∑ y ∈ Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x), f y := by
  rw [← Finset.sum_biUnion]
  · congr 1
    ext y
    simp
  · intro a _ b _ hab
    change Disjoint _ _
    rw [Finset.disjoint_left]
    intro y hya hyb
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hya hyb
    exact hab (hya.symm.trans hyb)

/-- `ρ_res` intertwines the Haar averages of adjacent levels. -/
lemma ρ_res_Pr_res (j : ℕ) (f : W (j + 1)) :
    ρ_res j (Pr_res (j + 1) f) = Pr_res j (ρ_res j f) := by
  ext x
  simp only [ρ_res, Pr_res, LinearMap.coe_mk, AddHom.coe_mk]
  rw [Finset.sum_const, card_modProj_fiber_clean j x, nsmul_eq_mul, sum_univ_eq_sum_fibers j f]
  simp only [Finset.mul_sum]
  refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun y _ => ?_
  push_cast
  ring

/-- `ρ_res` preserves the prepared state. -/
lemma ρ_res_q_res (j : ℕ) : ρ_res j (q_res (j + 1)) = q_res j := by
  ext x
  simp only [ρ_res, q_res, LinearMap.coe_mk, AddHom.coe_mk, Finset.sum_const,
    card_modProj_fiber_clean j x, nsmul_eq_mul]
  norm_num

/-- `Φ_res (j + 1) = Φ_res j ∘ ρ_res j`. -/
lemma Φ_res_ρ_res (j : ℕ) (f : W (j + 1)) :
    Φ_res (j + 1) f = Φ_res j (ρ_res j f) := by
  simp only [Φ_res, ρ_res, LinearMap.coe_mk, AddHom.coe_mk]
  rw [sum_univ_eq_sum_fibers j f]
  simp only [Finset.mul_sum]
  refine Finset.sum_congr rfl fun a _ => Finset.sum_congr rfl fun y _ => ?_
  ring

/-- **`PropertyC` on residue-class spaces** (a `def`: `PropertyC` carries the maps `ρ`). -/
noncomputable def residue_satisfies_PropertyC :
    PropertyC W Pr_res Φ_res q_res where
  ρ := ρ_res
  proj_intertwines j f := ρ_res_Pr_res j f
  state_compatible j := ρ_res_q_res j
  functional_compatible j f := Φ_res_ρ_res j f

/-- **`PropertyB` on residue-class spaces.** -/
theorem residue_satisfies_PropertyB :
    PropertyB W smear3_res Pr_res Φ_res q_res where
  smear_eval j := by
    unfold smear3_res Φ_res q_res
    simp only [LinearMap.coe_mk, AddHom.coe_mk, Finset.sum_const, Finset.card_univ,
      ZMod.card, nsmul_eq_mul, Nat.cast_pow, Nat.cast_ofNat]
    have hne : (3 : ℂ) ^ (j + 1) ≠ 0 := by positivity
    field_simp [hne]
  factors j := by
    unfold Φ_res Pr_res q_res
    simp only [LinearMap.coe_mk, AddHom.coe_mk, Finset.sum_const, Finset.card_univ,
      ZMod.card, nsmul_eq_mul, Nat.cast_pow, Nat.cast_ofNat]
    have hne : (3 : ℂ) ^ (j + 1) ≠ 0 := by positivity
    field_simp [hne]

/-! ## 3. Lazy residue walk `P_res j` and `PropertyA` -/

/-- `P_res j := (1/2) • id + (1/2) • Pr_res j`. -/
noncomputable def P_res (j : ℕ) : W j →ₗ[ℂ] W j :=
  (1 / 2 : ℂ) • LinearMap.id + (1 / 2 : ℂ) • Pr_res j

lemma P_res_apply (j : ℕ) (f : W j) (x : ZMod (3 ^ (j + 1))) :
    P_res j f x = (1 / 2 : ℂ) * f x + (1 / 2 : ℂ) * Pr_res j f x := by
  simp [P_res]

/-- Idempotence of the Haar average. -/
lemma Pr_res_idem (j : ℕ) (f : W j) :
    Pr_res j (Pr_res j f) = Pr_res j f := by
  ext x
  simp only [Pr_res, LinearMap.coe_mk, AddHom.coe_mk, Finset.sum_const, Finset.card_univ,
    ZMod.card, nsmul_eq_mul, Nat.cast_pow, Nat.cast_ofNat]
  have hne : (3 : ℂ) ^ (j + 1) ≠ 0 := by positivity
  rw [← mul_assoc, one_div_mul_cancel hne, one_mul]

lemma P_res_comp_Pr_res (j : ℕ) (f : W j) :
    P_res j (Pr_res j f) = Pr_res j f := by
  ext x
  rw [P_res_apply, Pr_res_idem]
  ring

/-- `(P_res j ^ n) f - Pr_res j f = (1/2)^n • (f - Pr_res j f)`. -/
lemma P_res_pow_sub_Pr_res (j n : ℕ) (f : W j) :
    ((P_res j) ^ n) f - Pr_res j f = (1 / 2 : ℂ) ^ n • (f - Pr_res j f) := by
  induction n with
  | zero =>
    simp
  | succ m ihm =>
    have h_step : ((P_res j) ^ (m + 1)) f = P_res j (((P_res j) ^ m) f) := by
      rw [pow_succ', LinearMap.mul_apply]
    have h_iter : ((P_res j) ^ m) f = Pr_res j f + (1 / 2 : ℂ) ^ m • (f - Pr_res j f) :=
      eq_add_of_sub_eq' ihm
    rw [h_step, h_iter, map_add, map_smul, P_res_comp_Pr_res]
    have h_pr_zero : Pr_res j (f - Pr_res j f) = 0 := by
      rw [map_sub, Pr_res_idem, sub_self]
    ext x
    simp only [Pi.add_apply, Pi.sub_apply, Pi.smul_apply, smul_eq_mul]
    rw [P_res_apply, h_pr_zero, Pi.zero_apply]
    simp only [Pi.sub_apply]
    ring

/-- `‖Pr_res j f‖ ≤ ‖f‖` in the sup-norm. -/
lemma norm_Pr_res_le (j : ℕ) (f : W j) :
    ‖Pr_res j f‖ ≤ ‖f‖ := by
  rw [pi_norm_le_iff_of_nonneg (norm_nonneg f)]
  intro x
  simp only [Pr_res, LinearMap.coe_mk, AddHom.coe_mk, norm_mul]
  have h_sum : ‖∑ y : ZMod (3 ^ (j + 1)), f y‖ ≤ (3 : ℝ) ^ (j + 1) * ‖f‖ := by
    calc ‖∑ y : ZMod (3 ^ (j + 1)), f y‖
        ≤ ∑ _y : ZMod (3 ^ (j + 1)), ‖f‖ := by
          refine le_trans (norm_sum_le _ _) ?_
          exact Finset.sum_le_sum fun y _ => norm_le_pi_norm f y
      _ = (3 : ℝ) ^ (j + 1) * ‖f‖ := by
          simp [ZMod.card]
  have h_coeff : ‖(1 / ((3 : ℂ) ^ (j + 1)))‖ = ((3 : ℝ) ^ (j + 1))⁻¹ := by
    simp [norm_inv, norm_pow]
  rw [h_coeff]
  calc ((3 : ℝ) ^ (j + 1))⁻¹ * ‖∑ y : ZMod (3 ^ (j + 1)), f y‖
      ≤ ((3 : ℝ) ^ (j + 1))⁻¹ * ((3 : ℝ) ^ (j + 1) * ‖f‖) := by
        gcongr
    _ = ‖f‖ := by
        have hpos : (3 : ℝ) ^ (j + 1) ≠ 0 := by positivity
        field_simp [hpos]

lemma norm_P_res_pow_sub_Pr_res (j n : ℕ) (f : W j) :
    ‖((P_res j) ^ n) f - Pr_res j f‖ ≤ 2 * (1 / 2 : ℝ) ^ n * ‖f‖ := by
  rw [P_res_pow_sub_Pr_res, norm_smul, norm_pow]
  have hhalf : ‖(1 / 2 : ℂ)‖ = (1 / 2 : ℝ) := by norm_num
  rw [hhalf]
  have h_diff : ‖f - Pr_res j f‖ ≤ 2 * ‖f‖ := by
    calc ‖f - Pr_res j f‖
        ≤ ‖f‖ + ‖Pr_res j f‖ := norm_sub_le f (Pr_res j f)
      _ ≤ ‖f‖ + ‖f‖ := add_le_add_left (norm_Pr_res_le j f) ‖f‖
      _ = 2 * ‖f‖ := by ring
  calc (1 / 2 : ℝ) ^ n * ‖f - Pr_res j f‖
      ≤ (1 / 2 : ℝ) ^ n * (2 * ‖f‖) := by gcongr
    _ = 2 * (1 / 2 : ℝ) ^ n * ‖f‖ := by ring

/-- **`PropertyA` on residue-class spaces** for the lazy walk `P_res`. -/
/-- Iterate convergence of the lazy walk at every vector. -/
lemma residue_iterate_tendsto (j : ℕ) (f : W j) :
    Tendsto (fun n : ℕ => ‖((P_res j) ^ n) f - (Pr_res j) f‖) atTop (nhds 0) := by
    have hHalf : Tendsto (fun n : ℕ => (1 / 2 : ℝ) ^ n) atTop (nhds 0) :=
      tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num)
    have hUpper : Tendsto (fun n : ℕ => 2 * (1 / 2 : ℝ) ^ n * ‖f‖) atTop (nhds 0) := by
      simpa only [mul_zero, zero_mul] using (hHalf.const_mul 2).mul_const ‖f‖
    apply squeeze_zero
    · intro n
      exact norm_nonneg _
    · intro n
      exact norm_P_res_pow_sub_Pr_res j n f
    · exact hUpper

theorem residue_satisfies_PropertyA :
    PropertyA W P_res Pr_res Φ_res q_res where
  operator_tendsto j := residue_iterate_tendsto j (q_res j)
  observable_bound j := by
    refine ⟨1, zero_le_one, fun f => ?_⟩
    rw [one_mul]
    -- `Φ_res j f` is the value of the constant function `Pr_res j f` at `0`
    have h_eq : Φ_res j f = Pr_res j f 0 := rfl
    rw [h_eq]
    exact le_trans (norm_le_pi_norm (Pr_res j f) 0) (norm_Pr_res_le j f)

/-! ## 4. End-to-end conditional reduction on `W j` -/

theorem residue_end_to_end_reduction
    (restrictedSmear : ℕ → ℂ) (spectatorProd : ℂ) (j d : ℕ)
    (h_hyp3 : Tendsto restrictedSmear atTop
      (nhds (smear3_res (j + d) * spectatorProd))) :
    (Tendsto (fun n => Φ_res j (((P_res j) ^ n) (q_res j))) atTop (nhds (smear3_res j))) ∧
    (Tendsto restrictedSmear atTop
      (nhds ((Φ_res j) ((Pr_res j) (q_res j)) * spectatorProd))) :=
  ⟨property_AB_imply_observable_convergence W
      residue_satisfies_PropertyA residue_satisfies_PropertyB j,
   combined_adelic_stationary_rg_reduction
      W restrictedSmear smear3_res spectatorProd
      residue_satisfies_PropertyB residue_satisfies_PropertyC j d h_hyp3⟩

/-! ## 5. Multi-scale intertwining and the affine shift `x ↦ 2x + 1` (`P_aff`) -/

theorem ρ_res_comp_P_res (j : ℕ) (f : W (j + 1)) :
    ρ_res j (P_res (j + 1) f) = P_res j (ρ_res j f) := by
  unfold P_res
  simp only [LinearMap.add_apply, LinearMap.smul_apply, LinearMap.id_coe, id_eq, map_add,
    map_smul]
  rw [ρ_res_Pr_res j f]

/-- Affine map `T_j(x) = 2 * x + 1` on `ZMod (3 ^ (j + 1))`. -/
def affineMap (j : ℕ) (x : ZMod (3 ^ (j + 1))) : ZMod (3 ^ (j + 1)) :=
  2 * x + 1

/-- `2` is a unit in `ZMod (3 ^ (j + 1))`. -/
lemma two_isUnit_zmod (j : ℕ) : IsUnit (2 : ZMod (3 ^ (j + 1))) := by
  have h := (ZMod.isUnit_iff_coprime 2 (3 ^ (j + 1))).mpr
    (Nat.Coprime.pow_right (j + 1) (by decide : Nat.Coprime 2 3))
  simpa using h

lemma affineMap_bijective (j : ℕ) : Function.Bijective (affineMap j) := by
  obtain ⟨u, hu⟩ := two_isUnit_zmod j
  refine ⟨fun x y hxy => ?_, fun y => ?_⟩
  · unfold affineMap at hxy
    have h1 : (2 : ZMod (3 ^ (j + 1))) * x = 2 * y := add_right_cancel hxy
    rw [← hu] at h1
    exact u.mul_left_cancel h1
  · refine ⟨(u⁻¹ : (ZMod (3 ^ (j + 1)))ˣ) * (y - 1), ?_⟩
    unfold affineMap
    rw [← hu, ← mul_assoc, Units.mul_inv, one_mul, sub_add_cancel]

lemma modProj_affineMap (j : ℕ) (y : ZMod (3 ^ (j + 1 + 1))) :
    modProj j (affineMap (j + 1) y) = affineMap j (modProj j y) := by
  unfold affineMap
  rw [map_add, map_mul, map_ofNat, map_one]

lemma affineMap_fiber_sum (j : ℕ) (f : W (j + 1)) (x : ZMod (3 ^ (j + 1))) :
    ∑ y ∈ Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x),
      f (affineMap (j + 1) y) =
    ∑ z ∈ Finset.univ.filter (fun z : ZMod (3 ^ (j + 1 + 1)) => modProj j z = affineMap j x),
      f z := by
  refine Finset.sum_bij (fun y _ => affineMap (j + 1) y) ?_ ?_ ?_ ?_
  · intro y hy
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hy ⊢
    rw [modProj_affineMap, hy]
  · intro y₁ _ y₂ _ h_eq
    exact (affineMap_bijective (j + 1)).1 h_eq
  · intro z hz
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hz
    obtain ⟨y, rfl⟩ := (affineMap_bijective (j + 1)).2 z
    refine ⟨y, ?_, rfl⟩
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    rw [modProj_affineMap] at hz
    exact (affineMap_bijective j).1 hz
  · intro _ _
    rfl

/-- Koopman shift `(U_res j f) x = f (2 * x + 1)`. -/
def U_res (j : ℕ) : W j →ₗ[ℂ] W j where
  toFun f x := f (affineMap j x)
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

lemma norm_U_res (j : ℕ) (f : W j) :
    ‖U_res j f‖ = ‖f‖ := by
  apply le_antisymm
  · rw [pi_norm_le_iff_of_nonneg (norm_nonneg f)]
    intro x
    exact norm_le_pi_norm f (affineMap j x)
  · rw [pi_norm_le_iff_of_nonneg (norm_nonneg (U_res j f))]
    intro y
    obtain ⟨x, rfl⟩ := (affineMap_bijective j).2 y
    exact norm_le_pi_norm (U_res j f) x

lemma Pr_res_comp_U_res (j : ℕ) (f : W j) :
    Pr_res j (U_res j f) = Pr_res j f := by
  ext x
  unfold Pr_res U_res
  simp only [LinearMap.coe_mk, AddHom.coe_mk]
  congr 1
  exact Equiv.sum_comp (Equiv.ofBijective (affineMap j) (affineMap_bijective j)) f

lemma U_res_comp_Pr_res (j : ℕ) (f : W j) :
    U_res j (Pr_res j f) = Pr_res j f := by
  ext x
  rfl

theorem ρ_res_comp_U_res (j : ℕ) (f : W (j + 1)) :
    ρ_res j (U_res (j + 1) f) = U_res j (ρ_res j f) := by
  ext x
  unfold ρ_res U_res
  simp only [LinearMap.coe_mk, AddHom.coe_mk]
  rw [affineMap_fiber_sum]

/-- `P_aff j := (1/2) • U_res j + (1/2) • Pr_res j`. -/
noncomputable def P_aff (j : ℕ) : W j →ₗ[ℂ] W j :=
  (1 / 2 : ℂ) • U_res j + (1 / 2 : ℂ) • Pr_res j

lemma P_aff_apply (j : ℕ) (f : W j) (x : ZMod (3 ^ (j + 1))) :
    P_aff j f x = (1 / 2 : ℂ) * U_res j f x + (1 / 2 : ℂ) * Pr_res j f x := by
  simp [P_aff]

theorem ρ_res_comp_P_aff (j : ℕ) (f : W (j + 1)) :
    ρ_res j (P_aff (j + 1) f) = P_aff j (ρ_res j f) := by
  unfold P_aff
  simp only [LinearMap.add_apply, LinearMap.smul_apply, map_add, map_smul]
  rw [ρ_res_comp_U_res j f, ρ_res_Pr_res j f]

lemma P_aff_comp_Pr_res (j : ℕ) (f : W j) :
    P_aff j (Pr_res j f) = Pr_res j f := by
  ext x
  rw [P_aff_apply, U_res_comp_Pr_res, Pr_res_idem]
  ring

lemma U_res_comm_Pr_res (j : ℕ) (f : W j) :
    U_res j (Pr_res j f) = Pr_res j (U_res j f) := by
  rw [U_res_comp_Pr_res, Pr_res_comp_U_res]

lemma P_aff_pow_sub_Pr_res (j n : ℕ) (f : W j) :
    ((P_aff j) ^ n) f - Pr_res j f =
      (1 / 2 : ℂ) ^ n • (((U_res j) ^ n) (f - Pr_res j f)) := by
  induction n with
  | zero =>
    simp
  | succ m ihm =>
    have h_step : ((P_aff j) ^ (m + 1)) f = P_aff j (((P_aff j) ^ m) f) := by
      rw [pow_succ', LinearMap.mul_apply]
    have h_iter : ((P_aff j) ^ m) f =
        Pr_res j f + (1 / 2 : ℂ) ^ m • (((U_res j) ^ m) (f - Pr_res j f)) :=
      eq_add_of_sub_eq' ihm
    have h_comm : ∀ k : ℕ, Pr_res j (((U_res j) ^ k) (f - Pr_res j f)) =
        Pr_res j (f - Pr_res j f) := by
      intro k
      induction k with
      | zero => simp
      | succ r ihr =>
        rw [pow_succ', LinearMap.mul_apply, Pr_res_comp_U_res, ihr]
    have h_g_mean_zero : Pr_res j (((U_res j) ^ m) (f - Pr_res j f)) = 0 := by
      rw [h_comm m, map_sub, Pr_res_idem, sub_self]
    have h_u_succ : ∀ x, ((U_res j) ^ (m + 1)) (f - Pr_res j f) x =
        U_res j (((U_res j) ^ m) (f - Pr_res j f)) x := by
      intro x
      rw [pow_succ', LinearMap.mul_apply]
    rw [h_step, h_iter, map_add, map_smul, P_aff_comp_Pr_res]
    ext x
    simp only [Pi.add_apply, Pi.sub_apply, Pi.smul_apply, smul_eq_mul]
    rw [P_aff_apply, h_g_mean_zero, Pi.zero_apply, h_u_succ x]
    ring

lemma norm_U_res_pow (j n : ℕ) (f : W j) :
    ‖((U_res j) ^ n) f‖ = ‖f‖ := by
  induction n with
  | zero => simp
  | succ m ihm =>
    rw [pow_succ', LinearMap.mul_apply, norm_U_res, ihm]

lemma norm_P_aff_pow_sub_Pr_res (j n : ℕ) (f : W j) :
    ‖((P_aff j) ^ n) f - Pr_res j f‖ ≤ 2 * (1 / 2 : ℝ) ^ n * ‖f‖ := by
  rw [P_aff_pow_sub_Pr_res, norm_smul, norm_pow, norm_U_res_pow]
  have hhalf : ‖(1 / 2 : ℂ)‖ = (1 / 2 : ℝ) := by norm_num
  rw [hhalf]
  have h_diff : ‖f - Pr_res j f‖ ≤ 2 * ‖f‖ := by
    calc ‖f - Pr_res j f‖
        ≤ ‖f‖ + ‖Pr_res j f‖ := norm_sub_le f (Pr_res j f)
      _ ≤ ‖f‖ + ‖f‖ := add_le_add_left (norm_Pr_res_le j f) ‖f‖
      _ = 2 * ‖f‖ := by ring
  calc (1 / 2 : ℝ) ^ n * ‖f - Pr_res j f‖
      ≤ (1 / 2 : ℝ) ^ n * (2 * ‖f‖) := by gcongr
    _ = 2 * (1 / 2 : ℝ) ^ n * ‖f‖ := by ring

/-- Iterate convergence of the affine walk at every vector. -/
lemma residue_affine_iterate_tendsto (j : ℕ) (f : W j) :
    Tendsto (fun n : ℕ => ‖((P_aff j) ^ n) f - (Pr_res j) f‖) atTop (nhds 0) := by
    have hHalf : Tendsto (fun n : ℕ => (1 / 2 : ℝ) ^ n) atTop (nhds 0) :=
      tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num)
    have hUpper : Tendsto (fun n : ℕ => 2 * (1 / 2 : ℝ) ^ n * ‖f‖) atTop (nhds 0) := by
      simpa only [mul_zero, zero_mul] using (hHalf.const_mul 2).mul_const ‖f‖
    apply squeeze_zero
    · intro n
      exact norm_nonneg _
    · intro n
      exact norm_P_aff_pow_sub_Pr_res j n f
    · exact hUpper

theorem residue_affine_satisfies_PropertyA :
    PropertyA W P_aff Pr_res Φ_res q_res where
  operator_tendsto j := residue_affine_iterate_tendsto j (q_res j)
  observable_bound := residue_satisfies_PropertyA.observable_bound

/-! ## 6. General 3-adic affine step ensembles and convex walks -/

/-- Global affine step `x ↦ a x + b` with `a` coprime to `3`. -/
structure AffineStep where
  a : ℤ
  b : ℤ
  coprime_three : Nat.Coprime a.natAbs 3

def AffineStep.apply (s : AffineStep) (j : ℕ) (x : ZMod (3 ^ (j + 1))) :
    ZMod (3 ^ (j + 1)) :=
  (s.a : ZMod (3 ^ (j + 1))) * x + (s.b : ZMod (3 ^ (j + 1)))

lemma AffineStep.a_isUnit (s : AffineStep) (j : ℕ) :
    IsUnit (s.a : ZMod (3 ^ (j + 1))) := by
  have hcop : Nat.Coprime s.a.natAbs (3 ^ (j + 1)) :=
    Nat.Coprime.pow_right (j + 1) s.coprime_three
  have hunit_nat : IsUnit ((s.a.natAbs : ℕ) : ZMod (3 ^ (j + 1))) :=
    (ZMod.isUnit_iff_coprime _ _).mpr hcop
  rcases Int.natAbs_eq s.a with ha | ha
  · rw [ha, Int.cast_natCast]
    exact hunit_nat
  · rw [ha, Int.cast_neg, Int.cast_natCast]
    exact hunit_nat.neg

lemma AffineStep.bijective (s : AffineStep) (j : ℕ) :
    Function.Bijective (s.apply j) := by
  obtain ⟨u, hu⟩ := s.a_isUnit j
  refine ⟨fun x y hxy => ?_, fun y => ?_⟩
  · unfold AffineStep.apply at hxy
    have h1 : (s.a : ZMod (3 ^ (j + 1))) * x = (s.a : ZMod (3 ^ (j + 1))) * y :=
      add_right_cancel hxy
    rw [← hu] at h1
    exact u.mul_left_cancel h1
  · refine ⟨(u⁻¹ : (ZMod (3 ^ (j + 1)))ˣ) * (y - (s.b : ZMod (3 ^ (j + 1)))), ?_⟩
    unfold AffineStep.apply
    rw [← hu, ← mul_assoc, Units.mul_inv, one_mul, sub_add_cancel]

lemma AffineStep.modProj_apply (s : AffineStep) (j : ℕ) (y : ZMod (3 ^ (j + 1 + 1))) :
    modProj j (s.apply (j + 1) y) = s.apply j (modProj j y) := by
  unfold AffineStep.apply
  rw [map_add, map_mul, map_intCast, map_intCast]

lemma AffineStep.fiber_sum (s : AffineStep) (j : ℕ) (f : W (j + 1))
    (x : ZMod (3 ^ (j + 1))) :
    ∑ y ∈ Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x),
      f (s.apply (j + 1) y) =
    ∑ z ∈ Finset.univ.filter (fun z : ZMod (3 ^ (j + 1 + 1)) => modProj j z = s.apply j x),
      f z := by
  refine Finset.sum_bij (fun y _ => s.apply (j + 1) y) ?_ ?_ ?_ ?_
  · intro y hy
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hy ⊢
    rw [s.modProj_apply, hy]
  · intro y₁ _ y₂ _ h_eq
    exact (s.bijective (j + 1)).1 h_eq
  · intro z hz
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hz
    obtain ⟨y, rfl⟩ := (s.bijective (j + 1)).2 z
    refine ⟨y, ?_, rfl⟩
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    rw [s.modProj_apply] at hz
    exact (s.bijective j).1 hz
  · intro _ _
    rfl

/-- Single-step Koopman shift `(U_step s j f) x = f (s.apply j x)`. -/
def U_step (s : AffineStep) (j : ℕ) : W j →ₗ[ℂ] W j where
  toFun f x := f (s.apply j x)
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

lemma norm_U_step (s : AffineStep) (j : ℕ) (f : W j) :
    ‖U_step s j f‖ = ‖f‖ := by
  apply le_antisymm
  · rw [pi_norm_le_iff_of_nonneg (norm_nonneg f)]
    intro x
    exact norm_le_pi_norm f (s.apply j x)
  · rw [pi_norm_le_iff_of_nonneg (norm_nonneg (U_step s j f))]
    intro y
    obtain ⟨x, rfl⟩ := (s.bijective j).2 y
    exact norm_le_pi_norm (U_step s j f) x

lemma Pr_res_comp_U_step (s : AffineStep) (j : ℕ) (f : W j) :
    Pr_res j (U_step s j f) = Pr_res j f := by
  ext x
  unfold Pr_res U_step
  simp only [LinearMap.coe_mk, AddHom.coe_mk]
  congr 1
  exact Equiv.sum_comp (Equiv.ofBijective (s.apply j) (s.bijective j)) f

lemma U_step_Pr_res (s : AffineStep) (j : ℕ) (f : W j) :
    U_step s j (Pr_res j f) = Pr_res j f := by
  ext x
  rfl

lemma ρ_res_comp_U_step (s : AffineStep) (j : ℕ) (f : W (j + 1)) :
    ρ_res j (U_step s (j + 1) f) = U_step s j (ρ_res j f) := by
  ext x
  unfold ρ_res U_step
  simp only [LinearMap.coe_mk, AddHom.coe_mk]
  rw [s.fiber_sum]

/-- Convex walk kernel: a finite list of affine steps with weights summing to `1` and total
absolute weight at most `1`. -/
structure WalkKernel where
  steps : List AffineStep
  weight : AffineStep → ℂ
  sum_weights_one : (steps.map weight).sum = 1
  sum_norm_le_one : (steps.map (fun s => ‖weight s‖)).sum ≤ 1

/-- Weighted Koopman sum over a list of steps (the underlying function of `U_walk`). Stated for
an arbitrary list so that its properties can be proved by induction on the list. -/
def walkSum (l : List AffineStep) (w : AffineStep → ℂ) (j : ℕ) (f : W j) : W j :=
  fun x => (l.map fun s => w s * U_step s j f x).sum

lemma walkSum_nil (w : AffineStep → ℂ) (j : ℕ) (f : W j) : walkSum [] w j f = 0 := by
  funext x
  simp [walkSum]

lemma walkSum_cons (s : AffineStep) (tl : List AffineStep) (w : AffineStep → ℂ) (j : ℕ)
    (f : W j) : walkSum (s :: tl) w j f = w s • U_step s j f + walkSum tl w j f := by
  funext x
  simp [walkSum]

lemma walkSum_add (l : List AffineStep) (w : AffineStep → ℂ) (j : ℕ) (f g : W j) :
    walkSum l w j (f + g) = walkSum l w j f + walkSum l w j g := by
  induction l with
  | nil => simp [walkSum_nil]
  | cons s tl ih =>
    rw [walkSum_cons, walkSum_cons, walkSum_cons, ih, map_add, smul_add]
    abel

lemma walkSum_smul (l : List AffineStep) (w : AffineStep → ℂ) (j : ℕ) (c : ℂ) (f : W j) :
    walkSum l w j (c • f) = c • walkSum l w j f := by
  induction l with
  | nil => simp [walkSum_nil]
  | cons s tl ih =>
    rw [walkSum_cons, walkSum_cons, ih, map_smul, smul_add,
      smul_comm (w s) c (U_step s j f)]

lemma Pr_res_walkSum (l : List AffineStep) (w : AffineStep → ℂ) (j : ℕ) (f : W j) :
    Pr_res j (walkSum l w j f) = (l.map w).sum • Pr_res j f := by
  induction l with
  | nil => simp [walkSum_nil]
  | cons s tl ih =>
    rw [walkSum_cons, map_add, map_smul, Pr_res_comp_U_step, ih, List.map_cons,
      List.sum_cons, add_smul]

lemma walkSum_Pr_res (l : List AffineStep) (w : AffineStep → ℂ) (j : ℕ) (f : W j) :
    walkSum l w j (Pr_res j f) = (l.map w).sum • Pr_res j f := by
  induction l with
  | nil => simp [walkSum_nil]
  | cons s tl ih =>
    rw [walkSum_cons, U_step_Pr_res, ih, List.map_cons, List.sum_cons, add_smul]

lemma ρ_res_walkSum (l : List AffineStep) (w : AffineStep → ℂ) (j : ℕ) (f : W (j + 1)) :
    ρ_res j (walkSum l w (j + 1) f) = walkSum l w j (ρ_res j f) := by
  induction l with
  | nil => simp [walkSum_nil]
  | cons s tl ih =>
    rw [walkSum_cons, walkSum_cons, map_add, map_smul, ρ_res_comp_U_step, ih]

lemma norm_walkSum_le (l : List AffineStep) (w : AffineStep → ℂ) (j : ℕ) (f : W j) :
    ‖walkSum l w j f‖ ≤ (l.map fun s => ‖w s‖).sum * ‖f‖ := by
  induction l with
  | nil => simp [walkSum_nil]
  | cons s tl ih =>
    rw [walkSum_cons]
    calc ‖w s • U_step s j f + walkSum tl w j f‖
        ≤ ‖w s • U_step s j f‖ + ‖walkSum tl w j f‖ := norm_add_le _ _
      _ ≤ ‖w s‖ * ‖f‖ + (tl.map fun s => ‖w s‖).sum * ‖f‖ := by
          rw [norm_smul, norm_U_step]
          exact add_le_add_left ih _
      _ = ((s :: tl).map fun s => ‖w s‖).sum * ‖f‖ := by
          simp only [List.map_cons, List.sum_cons]
          ring

/-- Weighted Koopman random-walk operator `U_walk K j`. -/
def U_walk (K : WalkKernel) (j : ℕ) : W j →ₗ[ℂ] W j where
  toFun := walkSum K.steps K.weight j
  map_add' := walkSum_add K.steps K.weight j
  map_smul' := walkSum_smul K.steps K.weight j

lemma U_walk_apply (K : WalkKernel) (j : ℕ) (f : W j) :
    U_walk K j f = walkSum K.steps K.weight j f := rfl

lemma norm_U_walk_le (K : WalkKernel) (j : ℕ) (f : W j) :
    ‖U_walk K j f‖ ≤ ‖f‖ := by
  calc ‖U_walk K j f‖ ≤ (K.steps.map fun s => ‖K.weight s‖).sum * ‖f‖ :=
        norm_walkSum_le K.steps K.weight j f
    _ ≤ 1 * ‖f‖ := mul_le_mul_of_nonneg_right K.sum_norm_le_one (norm_nonneg f)
    _ = ‖f‖ := one_mul _

lemma Pr_res_comp_U_walk (K : WalkKernel) (j : ℕ) (f : W j) :
    Pr_res j (U_walk K j f) = Pr_res j f := by
  rw [U_walk_apply, Pr_res_walkSum, K.sum_weights_one, one_smul]

lemma U_walk_comp_Pr_res (K : WalkKernel) (j : ℕ) (f : W j) :
    U_walk K j (Pr_res j f) = Pr_res j f := by
  rw [U_walk_apply, walkSum_Pr_res, K.sum_weights_one, one_smul]

theorem ρ_res_comp_U_walk (K : WalkKernel) (j : ℕ) (f : W (j + 1)) :
    ρ_res j (U_walk K (j + 1) f) = U_walk K j (ρ_res j f) := by
  rw [U_walk_apply, U_walk_apply, ρ_res_walkSum]

/-- `P_walk K j := (1/2) • U_walk K j + (1/2) • Pr_res j`. -/
noncomputable def P_walk (K : WalkKernel) (j : ℕ) : W j →ₗ[ℂ] W j :=
  (1 / 2 : ℂ) • U_walk K j + (1 / 2 : ℂ) • Pr_res j

lemma P_walk_apply (K : WalkKernel) (j : ℕ) (f : W j) (x : ZMod (3 ^ (j + 1))) :
    P_walk K j f x = (1 / 2 : ℂ) * U_walk K j f x + (1 / 2 : ℂ) * Pr_res j f x := by
  simp [P_walk]

theorem ρ_res_comp_P_walk (K : WalkKernel) (j : ℕ) (f : W (j + 1)) :
    ρ_res j (P_walk K (j + 1) f) = P_walk K j (ρ_res j f) := by
  unfold P_walk
  simp only [LinearMap.add_apply, LinearMap.smul_apply, map_add, map_smul]
  rw [ρ_res_comp_U_walk K j f, ρ_res_Pr_res j f]

lemma P_walk_comp_Pr_res (K : WalkKernel) (j : ℕ) (f : W j) :
    P_walk K j (Pr_res j f) = Pr_res j f := by
  ext x
  rw [P_walk_apply, U_walk_comp_Pr_res, Pr_res_idem]
  ring

lemma P_walk_pow_sub_Pr_res (K : WalkKernel) (j n : ℕ) (f : W j) :
    ((P_walk K j) ^ n) f - Pr_res j f =
      (1 / 2 : ℂ) ^ n • (((U_walk K j) ^ n) (f - Pr_res j f)) := by
  induction n with
  | zero => simp
  | succ m ihm =>
    have h_step : ((P_walk K j) ^ (m + 1)) f = P_walk K j (((P_walk K j) ^ m) f) := by
      rw [pow_succ', LinearMap.mul_apply]
    have h_iter : ((P_walk K j) ^ m) f =
        Pr_res j f + (1 / 2 : ℂ) ^ m • (((U_walk K j) ^ m) (f - Pr_res j f)) :=
      eq_add_of_sub_eq' ihm
    have h_comm : ∀ k : ℕ, Pr_res j (((U_walk K j) ^ k) (f - Pr_res j f)) =
        Pr_res j (f - Pr_res j f) := by
      intro k
      induction k with
      | zero => simp
      | succ r ihr =>
        rw [pow_succ', LinearMap.mul_apply, Pr_res_comp_U_walk, ihr]
    have h_g_mean_zero : Pr_res j (((U_walk K j) ^ m) (f - Pr_res j f)) = 0 := by
      rw [h_comm m, map_sub, Pr_res_idem, sub_self]
    have h_u_succ : ∀ x, ((U_walk K j) ^ (m + 1)) (f - Pr_res j f) x =
        U_walk K j (((U_walk K j) ^ m) (f - Pr_res j f)) x := by
      intro x
      rw [pow_succ', LinearMap.mul_apply]
    rw [h_step, h_iter, map_add, map_smul, P_walk_comp_Pr_res]
    ext x
    simp only [Pi.add_apply, Pi.sub_apply, Pi.smul_apply, smul_eq_mul]
    rw [P_walk_apply, h_g_mean_zero, Pi.zero_apply, h_u_succ x]
    ring

lemma norm_U_walk_pow_le (K : WalkKernel) (j n : ℕ) (f : W j) :
    ‖((U_walk K j) ^ n) f‖ ≤ ‖f‖ := by
  induction n with
  | zero => simp
  | succ m ihm =>
    rw [pow_succ', LinearMap.mul_apply]
    exact le_trans (norm_U_walk_le K j _) ihm

/-- Iterate convergence of the convex walk at every vector. -/
lemma residue_walk_iterate_tendsto (K : WalkKernel) (j : ℕ) (f : W j) :
    Tendsto (fun n : ℕ => ‖((P_walk K j) ^ n) f - (Pr_res j) f‖) atTop (nhds 0) := by
    have hHalf : Tendsto (fun n : ℕ => (1 / 2 : ℝ) ^ n) atTop (nhds 0) :=
      tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num)
    have hUpper : Tendsto (fun n : ℕ => 2 * (1 / 2 : ℝ) ^ n * ‖f‖) atTop (nhds 0) := by
      simpa only [mul_zero, zero_mul] using (hHalf.const_mul 2).mul_const ‖f‖
    apply squeeze_zero
    · intro n
      exact norm_nonneg _
    · intro n
      rw [P_walk_pow_sub_Pr_res, norm_smul, norm_pow]
      have hhalf : ‖(1 / 2 : ℂ)‖ = (1 / 2 : ℝ) := by norm_num
      rw [hhalf]
      have h_diff : ‖f - Pr_res j f‖ ≤ 2 * ‖f‖ := by
        calc ‖f - Pr_res j f‖
            ≤ ‖f‖ + ‖Pr_res j f‖ := norm_sub_le f (Pr_res j f)
          _ ≤ ‖f‖ + ‖f‖ := add_le_add_left (norm_Pr_res_le j f) ‖f‖
          _ = 2 * ‖f‖ := by ring
      calc (1 / 2 : ℝ) ^ n * ‖((U_walk K j) ^ n) (f - Pr_res j f)‖
          ≤ (1 / 2 : ℝ) ^ n * ‖f - Pr_res j f‖ :=
            mul_le_mul_of_nonneg_left (norm_U_walk_pow_le K j n _) (by positivity)
        _ ≤ (1 / 2 : ℝ) ^ n * (2 * ‖f‖) := by gcongr
        _ = 2 * (1 / 2 : ℝ) ^ n * ‖f‖ := by ring
    · exact hUpper

theorem residue_walk_satisfies_PropertyA (K : WalkKernel) :
    PropertyA W (P_walk K) Pr_res Φ_res q_res where
  operator_tendsto j := residue_walk_iterate_tendsto K j (q_res j)
  observable_bound := residue_satisfies_PropertyA.observable_bound

/-! ## 7. Additive characters and their eigenvalues -/

/-- `zeta j := exp (2πi / 3 ^ (j + 1))`. -/
noncomputable def zeta (j : ℕ) : ℂ :=
  Complex.exp (2 * Real.pi * Complex.I / ((3 : ℂ) ^ (j + 1)))

lemma zeta_pow_card (j : ℕ) :
    (zeta j) ^ (3 ^ (j + 1)) = 1 := by
  unfold zeta
  rw [← Complex.exp_nat_mul]
  have hne : ((3 : ℂ) ^ (j + 1)) ≠ 0 := by positivity
  have harg : ((3 ^ (j + 1) : ℕ) : ℂ) * (2 * Real.pi * Complex.I / ((3 : ℂ) ^ (j + 1))) =
      2 * Real.pi * Complex.I := by
    push_cast
    field_simp [hne]
  rw [harg, Complex.exp_two_pi_mul_I]

lemma zeta_zpow_card (j : ℕ) :
    (zeta j) ^ ((3 ^ (j + 1) : ℕ) : ℤ) = 1 := by
  rw [zpow_natCast, zeta_pow_card]

lemma zeta_succ_pow_three (j : ℕ) :
    (zeta (j + 1)) ^ 3 = zeta j := by
  unfold zeta
  rw [← Complex.exp_nat_mul]
  congr 1
  push_cast
  ring

lemma zeta_ne_zero (j : ℕ) : zeta j ≠ 0 :=
  Complex.exp_ne_zero _

/-- Additive character `χ_{j, ξ}(x) = zeta j ^ (ξ * x.val)`. -/
noncomputable def char (j : ℕ) (ξ : ℤ) : W j :=
  fun x => (zeta j) ^ (ξ * (x.val : ℤ))

lemma zeta_zpow_pow_card (j : ℕ) (ξ : ℤ) :
    ((zeta j) ^ ξ) ^ (3 ^ (j + 1)) = 1 := by
  rw [← zpow_natCast, ← zpow_mul, mul_comm, zpow_mul, zeta_zpow_card, one_zpow]

/-- `char j ξ x = (zeta j ^ ξ) ^ x.val`. -/
lemma char_eq_pow (j : ℕ) (ξ : ℤ) (x : ZMod (3 ^ (j + 1))) :
    char j ξ x = ((zeta j) ^ ξ) ^ x.val := by
  unfold char
  rw [zpow_mul, zpow_natCast]

/-- Character multiplicativity. (The request's first version was unfinished; its second
version rewrote with a `set` variable that `push_cast` could not match. This proof uses
`pow_eq_pow_mod` with `(zeta j ^ ξ) ^ 3 ^ (j + 1) = 1`.) -/
lemma char_add (j : ℕ) (ξ : ℤ) (x y : ZMod (3 ^ (j + 1))) :
    char j ξ (x + y) = char j ξ x * char j ξ y := by
  rw [char_eq_pow, char_eq_pow, char_eq_pow, ZMod.val_add,
    ← pow_eq_pow_mod _ (zeta_zpow_pow_card j ξ), pow_add]

lemma zeta_zpow_eq_one_iff (j : ℕ) (ξ : ℤ) :
    (zeta j) ^ ξ = 1 ↔ ((3 ^ (j + 1) : ℕ) : ℤ) ∣ ξ := by
  constructor
  · intro h
    unfold zeta at h
    rw [← Complex.exp_int_mul, Complex.exp_eq_one_iff] at h
    obtain ⟨k, hk⟩ := h
    have hpi : (2 * Real.pi * Complex.I) ≠ 0 := by
      simp [Real.pi_ne_zero, Complex.I_ne_zero]
    have hne : ((3 : ℂ) ^ (j + 1)) ≠ 0 := by positivity
    have hk_eq : (ξ : ℂ) = (k : ℂ) * ((3 : ℂ) ^ (j + 1)) := by
      have h2 : ((ξ : ℂ) / ((3 : ℂ) ^ (j + 1))) * (2 * Real.pi * Complex.I) =
          (k : ℂ) * (2 * Real.pi * Complex.I) := by
        calc ((ξ : ℂ) / ((3 : ℂ) ^ (j + 1))) * (2 * Real.pi * Complex.I)
            = (ξ : ℂ) * (2 * Real.pi * Complex.I / ((3 : ℂ) ^ (j + 1))) := by ring
          _ = (k : ℂ) * (2 * Real.pi * Complex.I) := hk
      have h3 : (ξ : ℂ) / ((3 : ℂ) ^ (j + 1)) = (k : ℂ) :=
        mul_right_cancel₀ hpi h2
      exact (div_eq_iff hne).mp h3
    refine ⟨k, ?_⟩
    exact_mod_cast hk_eq.trans (mul_comm _ _)
  · rintro ⟨k, rfl⟩
    rw [zpow_mul, zeta_zpow_card, one_zpow]

/-- Orthogonality: `∑ x, char j ξ x = 3 ^ (j + 1)` if `3 ^ (j + 1) ∣ ξ`, else `0`. -/
lemma sum_char_univ (j : ℕ) (ξ : ℤ) :
    ∑ x : ZMod (3 ^ (j + 1)), char j ξ x =
      if ((3 ^ (j + 1) : ℕ) : ℤ) ∣ ξ then ((3 : ℂ) ^ (j + 1)) else 0 := by
  have h_sum_geom : ∑ x : ZMod (3 ^ (j + 1)), char j ξ x =
      ∑ m ∈ Finset.range (3 ^ (j + 1)), ((zeta j) ^ ξ) ^ m :=
    Finset.sum_bij (fun x _ => x.val)
      (fun x _ => Finset.mem_range.mpr (ZMod.val_lt x))
      (fun a _ b _ h => ZMod.val_injective _ h)
      (fun b hb => ⟨(b : ZMod (3 ^ (j + 1))), Finset.mem_univ _,
        ZMod.val_natCast_of_lt (Finset.mem_range.mp hb)⟩)
      (fun x _ => char_eq_pow j ξ x)
  rw [h_sum_geom]
  by_cases hdvd : ((3 ^ (j + 1) : ℕ) : ℤ) ∣ ξ
  · rw [if_pos hdvd, (zeta_zpow_eq_one_iff j ξ).mpr hdvd]
    simp
  · rw [if_neg hdvd]
    have hr_ne : (zeta j) ^ ξ ≠ 1 := fun h => hdvd ((zeta_zpow_eq_one_iff j ξ).mp h)
    rw [geom_sum_eq hr_ne, zeta_zpow_pow_card, sub_self, zero_div]

theorem Pr_res_char (j : ℕ) (ξ : ℤ) :
    Pr_res j (char j ξ) =
      if ((3 ^ (j + 1) : ℕ) : ℤ) ∣ ξ then char j 0 else 0 := by
  ext x
  simp only [Pr_res, LinearMap.coe_mk, AddHom.coe_mk]
  rw [sum_char_univ]
  by_cases hdvd : ((3 ^ (j + 1) : ℕ) : ℤ) ∣ ξ
  · rw [if_pos hdvd, if_pos hdvd]
    have hne : (3 : ℂ) ^ (j + 1) ≠ 0 := by positivity
    unfold char
    simp only [zero_mul, zpow_zero]
    field_simp [hne]
  · rw [if_neg hdvd, if_neg hdvd]
    simp

theorem P_res_char (j : ℕ) (ξ : ℤ) :
    P_res j (char j ξ) =
      (if ((3 ^ (j + 1) : ℕ) : ℤ) ∣ ξ then (1 : ℂ) else (1 / 2 : ℂ)) • char j ξ := by
  ext x
  rw [P_res_apply, Pi.smul_apply, smul_eq_mul, Pr_res_char]
  by_cases hdvd : ((3 ^ (j + 1) : ℕ) : ℤ) ∣ ξ
  · rw [if_pos hdvd, if_pos hdvd]
    have hchar_one : ∀ y : ZMod (3 ^ (j + 1)), char j ξ y = 1 := by
      intro y
      unfold char
      rw [zpow_mul, (zeta_zpow_eq_one_iff j ξ).mpr hdvd, one_zpow]
    have hchar0 : char j 0 x = 1 := by unfold char; simp
    rw [hchar_one x, hchar0]
    ring
  · rw [if_neg hdvd, if_neg hdvd, Pi.zero_apply]
    ring

/-! ## 8. Fiber averaging on characters; intertwining with frequency decimation -/

/-- Pullback of `char j k` along `modProj j` is `char (j + 1) (3 * k)`. -/
lemma liftPullback_char (j : ℕ) (k : ℤ) :
    liftPullback j (char j k) = char (j + 1) (3 * k) := by
  ext y
  have hval : (modProj j y).val = y.val % 3 ^ (j + 1) := by
    rw [modProj, ZMod.castHom_apply, ZMod.cast_eq_val, ZMod.val_natCast]
  have hL : liftPullback j (char j k) y = ((zeta j) ^ k) ^ y.val := by
    show char j k (modProj j y) = _
    rw [char_eq_pow, hval, ← pow_eq_pow_mod _ (zeta_zpow_pow_card j k)]
  have hR : char (j + 1) (3 * k) y = ((zeta j) ^ k) ^ y.val := by
    unfold char
    rw [← zeta_succ_pow_three j, ← zpow_natCast (zeta (j + 1)) 3, ← zpow_mul,
      ← zpow_natCast _ y.val, ← zpow_mul]
    norm_num
  rw [hL, hR]

/-- Fiber sums are invariant under translation by `3 ^ (j + 1)`. -/
lemma fiber_sum_shift (j : ℕ) (g : W (j + 1)) (x : ZMod (3 ^ (j + 1))) :
    ∑ y ∈ Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x), g y =
      ∑ y ∈ Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x),
        g (y + ((3 ^ (j + 1) : ℕ) : ZMod (3 ^ (j + 1 + 1)))) := by
  refine Finset.sum_nbij' (fun y => y - ((3 ^ (j + 1) : ℕ) : ZMod (3 ^ (j + 1 + 1))))
    (fun y => y + ((3 ^ (j + 1) : ℕ) : ZMod (3 ^ (j + 1 + 1)))) ?_ ?_ ?_ ?_ ?_
  · intro y hy
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hy ⊢
    rw [map_sub, hy, modProj_three_pow, sub_zero]
  · intro y hy
    simp only [Finset.mem_filter, Finset.mem_univ, true_and] at hy ⊢
    rw [map_add, hy, modProj_three_pow, add_zero]
  · intro y _
    exact sub_add_cancel y _
  · intro y _
    exact add_sub_cancel_right y _
  · intro y _
    rw [sub_add_cancel]

/-- **Fiber averaging on characters:** `ρ_res j (char (j + 1) ξ)` is `char j (ξ / 3)` when
`3 ∣ ξ` and `0` otherwise. The case `¬ 3 ∣ ξ` is proved by translation invariance of the fiber
(`fiber_sum_shift`) instead of the request's explicit 3-element parametrization, whose proof was
cut off. -/
theorem ρ_res_char (j : ℕ) (ξ : ℤ) :
    ρ_res j (char (j + 1) ξ) =
      if (3 : ℤ) ∣ ξ then char j (ξ / 3) else 0 := by
  by_cases h3 : (3 : ℤ) ∣ ξ
  · rw [if_pos h3]
    obtain ⟨k, rfl⟩ := h3
    have hdiv : (3 * k) / 3 = k := Int.mul_ediv_cancel_left k (by decide)
    rw [hdiv, ← liftPullback_char, ρ_res_liftPullback]
  · rw [if_neg h3]
    ext x
    simp only [ρ_res, LinearMap.coe_mk, AddHom.coe_mk, Pi.zero_apply]
    have hshift := fiber_sum_shift j (char (j + 1) ξ) x
    simp only [char_add, ← Finset.sum_mul] at hshift
    have hc : char (j + 1) ξ ((3 ^ (j + 1) : ℕ) : ZMod (3 ^ (j + 1 + 1))) ≠ 1 := by
      intro h1
      unfold char at h1
      rw [ZMod.val_natCast_of_lt
        (Nat.pow_lt_pow_succ (by norm_num : 1 < 3) : 3 ^ (j + 1) < 3 ^ (j + 1 + 1))] at h1
      have hd := (zeta_zpow_eq_one_iff (j + 1) _).mp h1
      have h33 : ((3 ^ (j + 1 + 1) : ℕ) : ℤ) = 3 * ((3 ^ (j + 1) : ℕ) : ℤ) := by
        push_cast
        ring
      rw [h33] at hd
      have hne : ((3 ^ (j + 1) : ℕ) : ℤ) ≠ 0 := by positivity
      exact h3 ((mul_dvd_mul_iff_right hne).mp hd)
    have hS : ∑ y ∈ Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x),
        char (j + 1) ξ y = 0 := by
      have h1 : (∑ y ∈ Finset.univ.filter (fun y : ZMod (3 ^ (j + 1 + 1)) => modProj j y = x),
          char (j + 1) ξ y) *
          (char (j + 1) ξ ((3 ^ (j + 1) : ℕ) : ZMod (3 ^ (j + 1 + 1))) - 1) = 0 := by
        rw [mul_sub, mul_one, ← hshift, sub_self]
      rcases mul_eq_zero.mp h1 with h | h
      · exact h
      · exact absurd (sub_eq_zero.mp h) hc
    rw [hS, mul_zero]

/-- Fourier synthesis `fourierSynth j : (Fin (3 ^ (j + 1)) → ℂ) →ₗ[ℂ] W j`. -/
noncomputable def fourierSynth (j : ℕ) : (Fin (3 ^ (j + 1)) → ℂ) →ₗ[ℂ] W j where
  toFun c x := ∑ k : Fin (3 ^ (j + 1)), c k * char j (k.val : ℤ) x
  map_add' c₁ c₂ := by
    ext x
    simp only [Pi.add_apply, add_mul, Finset.sum_add_distrib]
  map_smul' a c := by
    ext x
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    exact Finset.sum_congr rfl fun k _ => by ring

lemma three_mul_lt (j : ℕ) (k : Fin (3 ^ (j + 1))) : 3 * k.val < 3 ^ (j + 1 + 1) := by
  have hk := k.isLt
  have hpow : 3 ^ (j + 1 + 1) = 3 * 3 ^ (j + 1) := by ring
  omega

/-- Frequency decimation `(ρ_freq j c) k = c (3 * k)`. -/
def ρ_freq (j : ℕ) : (Fin (3 ^ (j + 1 + 1)) → ℂ) →ₗ[ℂ] (Fin (3 ^ (j + 1)) → ℂ) where
  toFun c k := c ⟨3 * k.val, three_mul_lt j k⟩
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

/-- **Fourier intertwining:** `ρ_res j ∘ fourierSynth (j + 1) = fourierSynth j ∘ ρ_freq j`. -/
theorem fourierSynth_intertwines_ρ (j : ℕ) (c : Fin (3 ^ (j + 1 + 1)) → ℂ) :
    ρ_res j (fourierSynth (j + 1) c) = fourierSynth j (ρ_freq j c) := by
  have h_lin : fourierSynth (j + 1) c =
      ∑ ξ : Fin (3 ^ (j + 1 + 1)), c ξ • char (j + 1) (ξ.val : ℤ) := by
    ext y
    simp only [fourierSynth, LinearMap.coe_mk, AddHom.coe_mk, Finset.sum_apply, Pi.smul_apply,
      smul_eq_mul]
  rw [h_lin, map_sum]
  simp_rw [map_smul, ρ_res_char]
  have h_filt :
      ∑ ξ : Fin (3 ^ (j + 1 + 1)),
        c ξ • (if (3 : ℤ) ∣ (ξ.val : ℤ) then char j ((ξ.val : ℤ) / 3) else 0) =
      ∑ ξ ∈ Finset.univ.filter (fun ξ : Fin (3 ^ (j + 1 + 1)) => 3 ∣ ξ.val),
        c ξ • char j ((ξ.val : ℤ) / 3) := by
    rw [Finset.sum_filter]
    refine Finset.sum_congr rfl fun ξ _ => ?_
    by_cases h : 3 ∣ ξ.val
    · rw [if_pos (by exact_mod_cast h : (3 : ℤ) ∣ (ξ.val : ℤ)), if_pos h]
    · rw [if_neg (fun h' => h (by exact_mod_cast h')), if_neg h, smul_zero]
  rw [h_filt]
  have h_bij :
      ∑ ξ ∈ Finset.univ.filter (fun ξ : Fin (3 ^ (j + 1 + 1)) => 3 ∣ ξ.val),
        c ξ • char j ((ξ.val : ℤ) / 3) =
      ∑ k : Fin (3 ^ (j + 1)), ρ_freq j c k • char j (k.val : ℤ) := by
    symm
    refine Finset.sum_bij
      (fun (k : Fin (3 ^ (j + 1))) _ => (⟨3 * k.val, three_mul_lt j k⟩ : Fin (3 ^ (j + 1 + 1))))
      ?_ ?_ ?_ ?_
    · intro k _
      simp only [Finset.mem_filter, Finset.mem_univ, true_and]
      exact Nat.dvd_mul_right 3 k.val
    · intro k₁ _ k₂ _ h_eq
      have hv : 3 * k₁.val = 3 * k₂.val := congrArg Fin.val h_eq
      exact Fin.ext (by omega)
    · intro ξ hξ
      have hdvd : 3 ∣ ξ.val := (Finset.mem_filter.mp hξ).2
      obtain ⟨m, hm⟩ := hdvd
      have hm_lt : m < 3 ^ (j + 1) := by
        have hlt := ξ.isLt
        have hpow : 3 ^ (j + 1 + 1) = 3 * 3 ^ (j + 1) := by ring
        omega
      refine ⟨⟨m, hm_lt⟩, Finset.mem_univ _, ?_⟩
      ext
      exact hm.symm
    · intro k _
      have hdiv : ((3 * k.val : ℕ) : ℤ) / 3 = (k.val : ℤ) := by
        push_cast
        exact Int.mul_ediv_cancel_left _ (by decide)
      simp only [Fin.val_mk]
      rw [hdiv]
      rfl
  rw [h_bij]
  ext x
  simp only [fourierSynth, LinearMap.coe_mk, AddHom.coe_mk, Finset.sum_apply, Pi.smul_apply,
    smul_eq_mul]

/-! ## 9. Discrete Fourier inversion and Plancherel on `W j` -/

lemma char_neg_freq (j : ℕ) (ξ : ℤ) (x : ZMod (3 ^ (j + 1))) :
    char j (-ξ) x = (char j ξ x)⁻¹ := by
  unfold char
  rw [neg_mul, zpow_neg]

lemma char_ne_zero (j : ℕ) (ξ : ℤ) (x : ZMod (3 ^ (j + 1))) : char j ξ x ≠ 0 :=
  zpow_ne_zero _ (zeta_ne_zero j)

lemma char_sub (j : ℕ) (ξ : ℤ) (x y : ZMod (3 ^ (j + 1))) :
    char j ξ (x - y) = char j ξ x * char j (-ξ) y := by
  have h1 : char j ξ x = char j ξ (x - y) * char j ξ y := by
    rw [← char_add, sub_add_cancel]
  rw [h1, char_neg_freq, mul_assoc, mul_inv_cancel₀ (char_ne_zero j ξ y), mul_one]

lemma star_char (j : ℕ) (ξ : ℤ) (x : ZMod (3 ^ (j + 1))) :
    star (char j ξ x) = char j (-ξ) x := by
  unfold char zeta
  rw [← Complex.exp_int_mul, ← Complex.exp_int_mul, Complex.star_def, ← Complex.exp_conj]
  congr 1
  simp only [map_mul, map_div₀, map_intCast, Complex.conj_ofReal, Complex.conj_I,
    map_pow, map_ofNat]
  push_cast
  ring

/-- Dual orthogonality over frequencies. -/
lemma sum_char_freq (j : ℕ) (x : ZMod (3 ^ (j + 1))) :
    ∑ k : Fin (3 ^ (j + 1)), char j (k.val : ℤ) x =
      if x = 0 then ((3 : ℂ) ^ (j + 1)) else 0 := by
  have h_swap :
      ∑ k : Fin (3 ^ (j + 1)), char j (k.val : ℤ) x =
      ∑ k : Fin (3 ^ (j + 1)), char j (x.val : ℤ) (k.val : ZMod (3 ^ (j + 1))) := by
    refine Finset.sum_congr rfl fun k _ => ?_
    unfold char
    rw [ZMod.val_natCast_of_lt k.isLt, mul_comm]
  have h_reidx :
      ∑ k : Fin (3 ^ (j + 1)), char j (x.val : ℤ) (k.val : ZMod (3 ^ (j + 1))) =
      ∑ y : ZMod (3 ^ (j + 1)), char j (x.val : ℤ) y := by
    refine Finset.sum_bij (fun (k : Fin (3 ^ (j + 1))) _ => (k.val : ZMod (3 ^ (j + 1))))
      ?_ ?_ ?_ ?_
    · intro _ _
      exact Finset.mem_univ _
    · intro k₁ _ k₂ _ h_eq
      have hv := congrArg ZMod.val h_eq
      rw [ZMod.val_natCast_of_lt k₁.isLt, ZMod.val_natCast_of_lt k₂.isLt] at hv
      exact Fin.ext hv
    · intro y _
      refine ⟨⟨y.val, ZMod.val_lt y⟩, Finset.mem_univ _, ?_⟩
      simp [ZMod.natCast_zmod_val]
    · intro _ _
      rfl
  rw [h_swap, h_reidx, sum_char_univ]
  by_cases hx : x = 0
  · subst hx
    have hdvd : ((3 ^ (j + 1) : ℕ) : ℤ) ∣ ((0 : ZMod (3 ^ (j + 1))).val : ℤ) := by simp
    rw [if_pos hdvd, if_pos rfl]
  · rw [if_neg hx, if_neg]
    intro hdvd
    have h_nat_dvd : 3 ^ (j + 1) ∣ x.val := by exact_mod_cast hdvd
    have h_val_zero : x.val = 0 := Nat.eq_zero_of_dvd_of_lt h_nat_dvd (ZMod.val_lt x)
    exact hx ((ZMod.val_eq_zero x).mp h_val_zero)

/-- Inverse Fourier analysis `fourierAnalysis j : W j →ₗ[ℂ] (Fin (3 ^ (j + 1)) → ℂ)`. -/
noncomputable def fourierAnalysis (j : ℕ) : W j →ₗ[ℂ] (Fin (3 ^ (j + 1)) → ℂ) where
  toFun f k := (1 / ((3 : ℂ) ^ (j + 1))) *
    ∑ x : ZMod (3 ^ (j + 1)), f x * char j (-(k.val : ℤ)) x
  map_add' f g := by
    ext k
    simp only [Pi.add_apply, add_mul, Finset.sum_add_distrib, mul_add]
  map_smul' a f := by
    ext k
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    exact Finset.sum_congr rfl fun x _ => by ring

/-- `|k - ξ| < 3 ^ (j + 1)` and divisibility force `ξ = k` (used for orthogonality). -/
lemma fin_eq_of_dvd_sub (j : ℕ) (ξ k : Fin (3 ^ (j + 1)))
    (hdvd : ((3 ^ (j + 1) : ℕ) : ℤ) ∣ ((ξ.val : ℤ) - (k.val : ℤ))) : ξ = k := by
  have hξ := ξ.isLt
  have hk := k.isLt
  have h0 : (ξ.val : ℤ) - (k.val : ℤ) = 0 :=
    Int.eq_zero_of_abs_lt_dvd hdvd (abs_sub_lt_iff.mpr ⟨by omega, by omega⟩)
  exact Fin.ext (by omega)

/-- **Left inversion:** `fourierAnalysis j (fourierSynth j c) = c`. -/
theorem fourierAnalysis_synth (j : ℕ) (c : Fin (3 ^ (j + 1)) → ℂ) :
    fourierAnalysis j (fourierSynth j c) = c := by
  ext k
  simp only [fourierAnalysis, fourierSynth, LinearMap.coe_mk, AddHom.coe_mk]
  have h_expand :
      ∑ x : ZMod (3 ^ (j + 1)),
        (∑ ξ : Fin (3 ^ (j + 1)), c ξ * char j (ξ.val : ℤ) x) * char j (-(k.val : ℤ)) x =
      ∑ ξ : Fin (3 ^ (j + 1)),
        c ξ * ∑ x : ZMod (3 ^ (j + 1)), char j ((ξ.val : ℤ) - (k.val : ℤ)) x := by
    simp_rw [Finset.sum_mul]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun ξ _ => ?_
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl fun x _ => ?_
    have h_char_prod : char j (ξ.val : ℤ) x * char j (-(k.val : ℤ)) x =
        char j ((ξ.val : ℤ) - (k.val : ℤ)) x := by
      unfold char
      rw [← zpow_add₀ (zeta_ne_zero j)]
      congr 1
      ring
    rw [mul_assoc, h_char_prod]
  rw [h_expand]
  have h_ortho : ∀ ξ : Fin (3 ^ (j + 1)),
      c ξ * ∑ x : ZMod (3 ^ (j + 1)), char j ((ξ.val : ℤ) - (k.val : ℤ)) x =
      if ξ = k then c k * ((3 : ℂ) ^ (j + 1)) else 0 := by
    intro ξ
    rw [sum_char_univ]
    by_cases hξ : ξ = k
    · subst hξ
      have hdvd : ((3 ^ (j + 1) : ℕ) : ℤ) ∣ ((ξ.val : ℤ) - (ξ.val : ℤ)) := by simp
      rw [if_pos hdvd, if_pos rfl]
    · rw [if_neg hξ, if_neg (fun hdvd => hξ (fin_eq_of_dvd_sub j ξ k hdvd)), mul_zero]
  simp only [h_ortho, Finset.sum_ite_eq', Finset.mem_univ, if_true]
  have hne : (3 : ℂ) ^ (j + 1) ≠ 0 := by positivity
  field_simp [hne]

/-- **Right inversion:** `fourierSynth j (fourierAnalysis j f) = f`. -/
theorem fourierSynth_analysis (j : ℕ) (f : W j) :
    fourierSynth j (fourierAnalysis j f) = f := by
  ext x
  simp only [fourierSynth, fourierAnalysis, LinearMap.coe_mk, AddHom.coe_mk]
  have hne : (3 : ℂ) ^ (j + 1) ≠ 0 := by positivity
  calc ∑ k : Fin (3 ^ (j + 1)),
        ((1 / ((3 : ℂ) ^ (j + 1))) *
          ∑ y : ZMod (3 ^ (j + 1)), f y * char j (-(k.val : ℤ)) y) * char j (k.val : ℤ) x
      = (1 / ((3 : ℂ) ^ (j + 1))) *
          ∑ y : ZMod (3 ^ (j + 1)), f y * ∑ k : Fin (3 ^ (j + 1)), char j (k.val : ℤ) (x - y) := by
        simp_rw [Finset.mul_sum, Finset.sum_mul]
        rw [Finset.sum_comm]
        refine Finset.sum_congr rfl fun y _ => Finset.sum_congr rfl fun k _ => ?_
        rw [char_sub]
        ring
    _ = (1 / ((3 : ℂ) ^ (j + 1))) *
          ∑ y : ZMod (3 ^ (j + 1)), (if y = x then f y * ((3 : ℂ) ^ (j + 1)) else 0) := by
        congr 1
        refine Finset.sum_congr rfl fun y _ => ?_
        rw [sum_char_freq]
        by_cases h : y = x
        · subst h
          simp
        · rw [if_neg (sub_ne_zero.mpr (Ne.symm h)), if_neg h, mul_zero]
    _ = f x := by
        simp only [Finset.sum_ite_eq', Finset.mem_univ, if_true]
        field_simp [hne]

/-- Discrete Fourier linear isomorphism. -/
noncomputable def fourierEquiv (j : ℕ) : (Fin (3 ^ (j + 1)) → ℂ) ≃ₗ[ℂ] W j :=
  LinearEquiv.ofLinear (fourierSynth j) (fourierAnalysis j)
    (LinearMap.ext (fourierSynth_analysis j))
    (LinearMap.ext (fourierAnalysis_synth j))

/-- **Discrete Plancherel identity:**
`(1 / 3^(j+1)) * ∑ x, ‖f x‖ ^ 2 = ∑ k, ‖fourierAnalysis j f k‖ ^ 2`. (Proof rewritten: the
request's version was cut off and used `conv` paths that do not match the goal.) -/
theorem fourier_plancherel (j : ℕ) (f : W j) :
    (1 / ((3 : ℝ) ^ (j + 1))) * ∑ x : ZMod (3 ^ (j + 1)), ‖f x‖ ^ 2 =
      ∑ k : Fin (3 ^ (j + 1)), ‖fourierAnalysis j f k‖ ^ 2 := by
  set F := fourierAnalysis j f with hF
  have hsynth : ∀ x, ∑ k : Fin (3 ^ (j + 1)), F k * char j (k.val : ℤ) x = f x := by
    intro x
    have h := congrFun (fourierSynth_analysis j f) x
    exact h
  have hconjF : ∀ k : Fin (3 ^ (j + 1)), starRingEnd ℂ (F k) =
      (1 / ((3 : ℂ) ^ (j + 1))) *
        ∑ x : ZMod (3 ^ (j + 1)), starRingEnd ℂ (f x) * char j (k.val : ℤ) x := by
    intro k
    rw [hF]
    simp only [fourierAnalysis, LinearMap.coe_mk, AddHom.coe_mk, map_mul, map_sum]
    congr 1
    · simp
    · refine Finset.sum_congr rfl fun x _ => ?_
      rw [starRingEnd_apply (char j _ x), star_char, neg_neg]
  have hC : ∑ k : Fin (3 ^ (j + 1)), F k * starRingEnd ℂ (F k) =
      (1 / ((3 : ℂ) ^ (j + 1))) *
        ∑ x : ZMod (3 ^ (j + 1)), f x * starRingEnd ℂ (f x) := by
    simp_rw [hconjF, Finset.mul_sum]
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl fun x _ => ?_
    calc ∑ k : Fin (3 ^ (j + 1)), F k * ((1 / ((3 : ℂ) ^ (j + 1))) *
          (starRingEnd ℂ (f x) * char j (k.val : ℤ) x))
        = (1 / ((3 : ℂ) ^ (j + 1))) * starRingEnd ℂ (f x) *
            ∑ k : Fin (3 ^ (j + 1)), F k * char j (k.val : ℤ) x := by
          rw [Finset.mul_sum]
          exact Finset.sum_congr rfl fun k _ => by ring
      _ = (1 / ((3 : ℂ) ^ (j + 1))) * (f x * starRingEnd ℂ (f x)) := by
          rw [hsynth x]
          ring
  simp_rw [Complex.mul_conj, Complex.normSq_eq_norm_sq] at hC
  exact_mod_cast hC.symm

/-- Fourier conjugation of an operator on `W j`. -/
noncomputable def fourierConj (j : ℕ) (T : W j →ₗ[ℂ] W j) :
    (Fin (3 ^ (j + 1)) → ℂ) →ₗ[ℂ] (Fin (3 ^ (j + 1)) → ℂ) :=
  (fourierAnalysis j).comp (T.comp (fourierSynth j))

/-- The Haar average of a synthesized function is its `k = 0` coefficient. -/
lemma Pr_res_fourierSynth (j : ℕ) (c : Fin (3 ^ (j + 1)) → ℂ) :
    Pr_res j (fourierSynth j c) = fun _ => c ⟨0, by positivity⟩ := by
  funext x
  simp only [Pr_res, fourierSynth, LinearMap.coe_mk, AddHom.coe_mk]
  rw [Finset.sum_comm]
  simp_rw [← Finset.mul_sum, sum_char_univ]
  have hk : ∀ k : Fin (3 ^ (j + 1)),
      (((3 ^ (j + 1) : ℕ) : ℤ) ∣ (k.val : ℤ)) ↔ k = ⟨0, by positivity⟩ := by
    intro k
    constructor
    · intro h
      have h' : 3 ^ (j + 1) ∣ k.val := by exact_mod_cast h
      exact Fin.ext (Nat.eq_zero_of_dvd_of_lt h' k.isLt)
    · rintro rfl
      simp
  simp_rw [hk, mul_ite, mul_zero]
  simp only [Finset.sum_ite_eq', Finset.mem_univ, if_true]
  have hne : (3 : ℂ) ^ (j + 1) ≠ 0 := by positivity
  field_simp [hne]

/-- Under Fourier conjugation, `Pr_res j` is the projection onto the `k = 0` mode. -/
theorem fourierConj_Pr_res (j : ℕ) (c : Fin (3 ^ (j + 1)) → ℂ) (k : Fin (3 ^ (j + 1))) :
    fourierConj j (Pr_res j) c k = if k.val = 0 then c k else 0 := by
  unfold fourierConj
  simp only [LinearMap.comp_apply]
  rw [Pr_res_fourierSynth]
  simp only [fourierAnalysis, LinearMap.coe_mk, AddHom.coe_mk]
  rw [← Finset.mul_sum, sum_char_univ]
  have hne : (3 : ℂ) ^ (j + 1) ≠ 0 := by positivity
  by_cases hk : k.val = 0
  · have hd : ((3 ^ (j + 1) : ℕ) : ℤ) ∣ -(k.val : ℤ) := by rw [hk]; simp
    have hk0 : k = ⟨0, by positivity⟩ := Fin.ext hk
    rw [if_pos hd, if_pos hk, hk0]
    field_simp [hne]
  · rw [if_neg hk, if_neg, mul_zero, mul_zero]
    intro hd
    have h' : 3 ^ (j + 1) ∣ k.val := by exact_mod_cast (dvd_neg.mp hd)
    exact hk (Nat.eq_zero_of_dvd_of_lt h' k.isLt)

end AdelicPlace3Unification.ResidueLayer

/-! # Part 4: Finite group towers, the `p`-adic tree, finite Euler products (from Notes 9)

Notes 9 instantiates the abstract framework on the rooted `p`-ary tree: level `j` is
`ZMod (p ^ j)`, decimation sums over the `p` children of a vertex, the observable is total mass
and the prepared state is the point mass `δ₀`. It then adds a lazy walk with rate `λ`, a finite
Euler product over a set `S` of primes, a two-place tensor family on
`ZMod (p ^ j) × ZMod (r ^ j)` and a correlated (non-product) prepared state.

Adaptation to this file:
* The notes' bundled `AdelicLevelFamily` is not used; everything instantiates the unbundled
  `PropertyA`/`B`/`C` of Part 1.
* The common algebra is proved once, in `FiniteTower`, for any tower of finite additive groups
  `G j` with surjective homomorphisms `π j : G (j + 1) →+ G j`. The `p`-adic tree and the
  two-place family are two instances of it; the notes repeated the same proofs in each file.
* The norm is Mathlib's sup norm on functions on a finite type (the notes' prose mentions
  `ℓ²` or `ℓ¹`; the Lean statements use the sup norm throughout).
* The notes' level-dependent weights `w p j` with the invariance hypothesis
  `w p (j + 1) = w p j` reduce to level-independent weights `w p`; that form is used here.
* The local zeta factor is written `(1 - (p ^ s)⁻¹)⁻¹` with a natural exponent `s`, so that the
  check at `s = 2` is a `norm_num` computation (the notes used the complex power `p ^ (-s)`).

Scope: these are model instances. The lazy walk has the gap `1 - λ` by construction, uniformly
in the level `j`; nothing here concerns the Collatz/Syracuse operator. The Euler-product limit is
the product of the chosen weights: with `w p = (1 - p ^ (-s))⁻¹` it is a finite partial Euler
product, and it says nothing about `ζ(s)` or any `L`-function.
-/

noncomputable section

namespace AdelicPlace3Unification.FiniteTower

/-- Complex functions on level `j` of a tower `G`. -/
abbrev Fn (G : ℕ → Type*) (j : ℕ) : Type _ := G j → ℂ

variable (G : ℕ → Type*) [∀ j, Fintype (G j)] [∀ j, DecidableEq (G j)]
  [∀ j, AddCommGroup (G j)]

/-! ## 1. Point masses, the Haar average, total mass -/

lemma card_pos (j : ℕ) : 0 < Fintype.card (G j) := Fintype.card_pos_iff.mpr ⟨0⟩

lemma card_ne_zero (j : ℕ) : (Fintype.card (G j) : ℂ) ≠ 0 := by
  exact_mod_cast (card_pos G j).ne'

/-- Point mass at `a`. -/
def delta (j : ℕ) (a : G j) : Fn G j := fun b => if b = a then 1 else 0

lemma delta_apply (j : ℕ) (a b : G j) : delta G j a b = if b = a then 1 else 0 := rfl

lemma sum_delta (j : ℕ) (a : G j) : ∑ b, delta G j a b = 1 := by
  simp [delta]

/-- Every function is the sum of its point masses. -/
lemma eq_sum_delta (j : ℕ) (x : Fn G j) : x = ∑ a, x a • delta G j a := by
  ext b
  simp [delta, Finset.sum_apply]

/-- A linear map is determined by its values on point masses. -/
lemma apply_eq_sum_delta (j : ℕ) (A : Fn G j →ₗ[ℂ] Fn G j) (x : Fn G j) (b : G j) :
    A x b = ∑ a, x a * A (delta G j a) b := by
  conv_lhs => rw [eq_sum_delta G j x]
  rw [map_sum, Finset.sum_apply]
  refine Finset.sum_congr rfl fun a _ => ?_
  rw [map_smul, Pi.smul_apply, smul_eq_mul]

/-- The prepared state `δ₀`. -/
def q0 (j : ℕ) : Fn G j := delta G j 0

/-- Haar average: the constant function with value the mean of `f`. -/
def avg (j : ℕ) : Fn G j →ₗ[ℂ] Fn G j where
  toFun f _ := ((Fintype.card (G j) : ℂ))⁻¹ * ∑ b, f b
  map_add' f g := by
    ext a
    simp only [Pi.add_apply]
    rw [Finset.sum_add_distrib, mul_add]
  map_smul' c f := by
    ext a
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    exact Finset.sum_congr rfl fun b _ => by ring

lemma avg_apply (j : ℕ) (f : Fn G j) (a : G j) :
    avg G j f a = ((Fintype.card (G j) : ℂ))⁻¹ * ∑ b, f b := rfl

lemma avg_idem (j : ℕ) (f : Fn G j) : avg G j (avg G j f) = avg G j f := by
  ext a
  simp only [avg_apply, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  rw [← mul_assoc ((Fintype.card (G j) : ℂ))⁻¹, inv_mul_cancel₀ (card_ne_zero G j), one_mul]

lemma avg_delta_apply (j : ℕ) (a b : G j) :
    avg G j (delta G j a) b = ((Fintype.card (G j) : ℂ))⁻¹ := by
  rw [avg_apply, sum_delta, mul_one]

/-- Weighted total mass `f ↦ w * ∑ b, f b` (the notes' observable is the case `w = 1`). -/
def totalMass (w : ℂ) (j : ℕ) : Fn G j →ₗ[ℂ] ℂ where
  toFun f := w * ∑ b, f b
  map_add' f g := by
    simp only [Pi.add_apply]
    rw [Finset.sum_add_distrib, mul_add]
  map_smul' c f := by
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    exact Finset.sum_congr rfl fun b _ => by ring

lemma totalMass_apply (w : ℂ) (j : ℕ) (f : Fn G j) : totalMass G w j f = w * ∑ b, f b := rfl

lemma totalMass_delta (w : ℂ) (j : ℕ) (a : G j) : totalMass G w j (delta G j a) = w := by
  rw [totalMass_apply, sum_delta, mul_one]

lemma totalMass_avg (w : ℂ) (j : ℕ) (f : Fn G j) :
    totalMass G w j (avg G j f) = totalMass G w j f := by
  simp only [totalMass_apply, avg_apply, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  rw [← mul_assoc (Fintype.card (G j) : ℂ), mul_inv_cancel₀ (card_ne_zero G j), one_mul]

/-! ## 2. Norm estimates (sup norm) -/

lemma norm_sum_le_card (j : ℕ) (f : Fn G j) :
    ‖∑ b, f b‖ ≤ Fintype.card (G j) * ‖f‖ := by
  calc ‖∑ b, f b‖ ≤ ∑ b, ‖f b‖ := norm_sum_le _ _
    _ ≤ ∑ _b : G j, ‖f‖ := Finset.sum_le_sum fun b _ => norm_le_pi_norm f b
    _ = Fintype.card (G j) * ‖f‖ := by simp

lemma norm_totalMass_le (w : ℂ) (j : ℕ) (f : Fn G j) :
    ‖totalMass G w j f‖ ≤ (‖w‖ * Fintype.card (G j)) * ‖f‖ := by
  rw [totalMass_apply, norm_mul, mul_assoc]
  gcongr
  exact norm_sum_le_card G j f

lemma norm_avg_le (j : ℕ) (f : Fn G j) : ‖avg G j f‖ ≤ ‖f‖ := by
  rw [pi_norm_le_iff_of_nonneg (norm_nonneg f)]
  intro a
  rw [avg_apply, norm_mul, norm_inv, Complex.norm_natCast]
  have hN : (0 : ℝ) < Fintype.card (G j) := by exact_mod_cast card_pos G j
  calc ((Fintype.card (G j) : ℝ))⁻¹ * ‖∑ b, f b‖
      ≤ ((Fintype.card (G j) : ℝ))⁻¹ * (Fintype.card (G j) * ‖f‖) := by
        gcongr
        exact norm_sum_le_card G j f
    _ = ‖f‖ := by rw [← mul_assoc, inv_mul_cancel₀ hN.ne', one_mul]

lemma norm_delta_le (j : ℕ) (a : G j) : ‖delta G j a‖ ≤ 1 := by
  rw [pi_norm_le_iff_of_nonneg zero_le_one]
  intro b
  by_cases h : b = a <;> simp [delta, h]

/-- `‖δ_a - avg δ_a‖ ≤ 1`: the entries are `1 - 1/N` and `-1/N` (the notes' bound). -/
lemma norm_delta_sub_avg_le (j : ℕ) (a : G j) :
    ‖delta G j a - avg G j (delta G j a)‖ ≤ 1 := by
  rw [pi_norm_le_iff_of_nonneg zero_le_one]
  intro b
  have hN : (1 : ℝ) ≤ (Fintype.card (G j) : ℝ) := by exact_mod_cast card_pos G j
  have hi0 : 0 ≤ ((Fintype.card (G j) : ℝ))⁻¹ := inv_nonneg.mpr (by linarith)
  have hi1 : ((Fintype.card (G j) : ℝ))⁻¹ ≤ 1 := inv_le_one_of_one_le₀ hN
  have hcast : ((Fintype.card (G j) : ℂ))⁻¹ = ((((Fintype.card (G j) : ℝ))⁻¹ : ℝ) : ℂ) := by
    push_cast
    try ring
  rw [Pi.sub_apply, avg_delta_apply, delta_apply, hcast]
  by_cases hb : b = a
  · rw [if_pos hb]
    have h1 : (1 : ℂ) - ((((Fintype.card (G j) : ℝ))⁻¹ : ℝ) : ℂ) =
        ((1 - ((Fintype.card (G j) : ℝ))⁻¹ : ℝ) : ℂ) := by
      push_cast
      try ring
    rw [h1, Complex.norm_real,
      Real.norm_of_nonneg (show (0 : ℝ) ≤ 1 - ((Fintype.card (G j) : ℝ))⁻¹ by linarith)]
    linarith
  · rw [if_neg hb, zero_sub, norm_neg, Complex.norm_real, Real.norm_of_nonneg hi0]
    exact hi1

/-! ## 3. The lazy walk `λ • id + (1 - λ) • avg` -/

/-- Lazy walk with rate `λ`; `λ = 0` gives `avg` itself (the notes' baseline `P = Pr`). -/
def lazy (lam : ℝ) (j : ℕ) : Fn G j →ₗ[ℂ] Fn G j :=
  (lam : ℂ) • LinearMap.id + ((1 - lam : ℝ) : ℂ) • avg G j

lemma lazy_apply (lam : ℝ) (j : ℕ) (f : Fn G j) :
    lazy G lam j f = (lam : ℂ) • f + ((1 - lam : ℝ) : ℂ) • avg G j f := rfl

lemma lazy_zero_apply (j : ℕ) (f : Fn G j) : lazy G 0 j f = avg G j f := by
  simp [lazy_apply]

lemma lazy_avg (lam : ℝ) (j : ℕ) (f : Fn G j) : lazy G lam j (avg G j f) = avg G j f := by
  rw [lazy_apply, avg_idem, ← add_smul]
  have h : (lam : ℂ) + ((1 - lam : ℝ) : ℂ) = 1 := by push_cast; ring
  rw [h, one_smul]

/-- Exact iterate formula: `(lazy ^ n) f - avg f = λ ^ n • (f - avg f)`. -/
lemma lazy_pow_sub_avg (lam : ℝ) (j n : ℕ) (f : Fn G j) :
    (lazy G lam j ^ n) f - avg G j f = (lam : ℂ) ^ n • (f - avg G j f) := by
  induction n with
  | zero => simp
  | succ m ih =>
    have h_iter : (lazy G lam j ^ m) f = avg G j f + (lam : ℂ) ^ m • (f - avg G j f) :=
      eq_add_of_sub_eq' ih
    have h0 : avg G j (f - avg G j f) = 0 := by rw [map_sub, avg_idem, sub_self]
    rw [pow_succ' (lazy G lam j) m, LinearMap.mul_apply, h_iter, map_add, map_smul, lazy_avg,
      lazy_apply G lam j (f - avg G j f), h0, smul_zero, add_zero, pow_succ (lam : ℂ) m,
      mul_smul]
    abel

/-- For `0 ≤ λ ≤ 1` the lazy walk does not increase the sup norm. -/
lemma lazy_norm_le (lam : ℝ) (h0 : 0 ≤ lam) (h1 : lam ≤ 1) (j : ℕ) (f : Fn G j) :
    ‖lazy G lam j f‖ ≤ ‖f‖ := by
  rw [lazy_apply]
  calc ‖(lam : ℂ) • f + ((1 - lam : ℝ) : ℂ) • avg G j f‖
      ≤ ‖(lam : ℂ) • f‖ + ‖((1 - lam : ℝ) : ℂ) • avg G j f‖ := norm_add_le _ _
    _ = lam * ‖f‖ + (1 - lam) * ‖avg G j f‖ := by
        rw [norm_smul, norm_smul, Complex.norm_real, Complex.norm_real, Real.norm_of_nonneg h0,
          Real.norm_of_nonneg (sub_nonneg.mpr h1)]
    _ ≤ lam * ‖f‖ + (1 - lam) * ‖f‖ :=
        add_le_add_left (mul_le_mul_of_nonneg_left (norm_avg_le G j f) (sub_nonneg.mpr h1)) _
    _ = ‖f‖ := by ring

lemma lazy_pow_norm_le (lam : ℝ) (h0 : 0 ≤ lam) (h1 : lam ≤ 1) (j n : ℕ) (f : Fn G j) :
    ‖(lazy G lam j ^ n) f‖ ≤ ‖f‖ := by
  induction n with
  | zero => simp
  | succ m ih =>
    rw [pow_succ' (lazy G lam j) m, LinearMap.mul_apply]
    exact (lazy_norm_le G lam h0 h1 j _).trans ih

/-- Geometric bound at a point mass, uniform in the level `j`. -/
lemma norm_lazy_pow_delta_sub (lam : ℝ) (h0 : 0 ≤ lam) (j n : ℕ) (a : G j) :
    ‖(lazy G lam j ^ n) (delta G j a) - avg G j (delta G j a)‖ ≤ lam ^ n := by
  rw [lazy_pow_sub_avg, norm_smul, norm_pow, Complex.norm_real, Real.norm_of_nonneg h0]
  calc lam ^ n * ‖delta G j a - avg G j (delta G j a)‖ ≤ lam ^ n * 1 :=
        mul_le_mul_of_nonneg_left (norm_delta_sub_avg_le G j a) (pow_nonneg h0 n)
    _ = lam ^ n := mul_one _

lemma lazy_iterate_tendsto_delta (lam : ℝ) (h0 : 0 ≤ lam) (h1 : lam < 1) (j : ℕ) (a : G j) :
    Tendsto (fun n : ℕ => ‖(lazy G lam j ^ n) (delta G j a) - avg G j (delta G j a)‖)
      atTop (nhds 0) :=
  squeeze_zero (fun n => norm_nonneg _) (fun n => norm_lazy_pow_delta_sub G lam h0 j n a)
    (tendsto_pow_atTop_nhds_zero_of_lt_one h0 h1)

/-! ## 4. Fiber-sum decimation along `π j : G (j + 1) →+ G j` -/

variable {G}
variable (π : ∀ j, G (j + 1) →+ G j)

/-- The fiber of `π j` over `a`. -/
def fiber (j : ℕ) (a : G j) : Finset (G (j + 1)) := Finset.univ.filter (fun b => π j b = a)

/-- Decimation: sum over the fiber (the notes' `padicDecimation`). -/
def fiberSum (j : ℕ) : Fn G (j + 1) →ₗ[ℂ] Fn G j where
  toFun f a := ∑ b ∈ fiber π j a, f b
  map_add' f g := by
    ext a
    simp only [Pi.add_apply]
    rw [Finset.sum_add_distrib]
  map_smul' c f := by
    ext a
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply]
    rw [Finset.mul_sum]

lemma fiberSum_apply (j : ℕ) (f : Fn G (j + 1)) (a : G j) :
    fiberSum π j f a = ∑ b ∈ fiber π j a, f b := rfl

lemma sum_fibers (j : ℕ) (f : Fn G (j + 1)) :
    ∑ a : G j, ∑ b ∈ fiber π j a, f b = ∑ b, f b := by
  rw [← Finset.sum_biUnion]
  · congr 1
    ext b
    simp [fiber]
  · intro a _ a' _ h
    change Disjoint _ _
    rw [Finset.disjoint_left]
    intro b hb hb'
    simp only [fiber, Finset.mem_filter, Finset.mem_univ, true_and] at hb hb'
    exact h (hb.symm.trans hb')

lemma fiberSum_delta (j : ℕ) (b₀ : G (j + 1)) :
    fiberSum π j (delta G (j + 1) b₀) = delta G j (π j b₀) := by
  ext a
  rw [fiberSum_apply]
  simp only [delta_apply]
  rw [Finset.sum_ite_eq']
  simp only [fiber, Finset.mem_filter, Finset.mem_univ, true_and]
  by_cases h : π j b₀ = a
  · rw [if_pos h, if_pos h.symm]
  · rw [if_neg h, if_neg (Ne.symm h)]

lemma totalMass_fiberSum (w : ℂ) (j : ℕ) (f : Fn G (j + 1)) :
    totalMass G w (j + 1) f = totalMass G w j (fiberSum π j f) := by
  simp only [totalMass_apply, fiberSum_apply]
  rw [sum_fibers π j f]

lemma card_fiber_eq (hπ : ∀ j, Function.Surjective (π j)) (j : ℕ) (a a' : G j) : (fiber π j a).card = (fiber π j a').card := by
  obtain ⟨y₀, hy₀⟩ := hπ j (a' - a)
  refine Finset.card_bij (fun y _ => y + y₀) ?_ ?_ ?_
  · intro y hy
    simp only [fiber, Finset.mem_filter, Finset.mem_univ, true_and] at hy ⊢
    rw [map_add, hy, hy₀]
    abel
  · intro y₁ _ y₂ _ h
    exact add_right_cancel h
  · intro z hz
    simp only [fiber, Finset.mem_filter, Finset.mem_univ, true_and] at hz
    refine ⟨z - y₀, ?_, sub_add_cancel z y₀⟩
    simp only [fiber, Finset.mem_filter, Finset.mem_univ, true_and]
    rw [map_sub, hz, hy₀]
    abel

/-- Every fiber has `|G (j + 1)| / |G j|` points (for the `p`-adic tree: `p` points). -/
lemma card_fiber_mul (hπ : ∀ j, Function.Surjective (π j)) (j : ℕ) (a : G j) :
    (fiber π j a).card * Fintype.card (G j) = Fintype.card (G (j + 1)) := by
  have h_sum : ∑ a' : G j, (fiber π j a').card = Fintype.card (G (j + 1)) := by
    rw [← Finset.card_univ, ← Finset.card_biUnion]
    · congr 1
      ext b
      simp [fiber]
    · intro a₁ _ a₂ _ h
      change Disjoint _ _
      rw [Finset.disjoint_left]
      intro b hb hb'
      simp only [fiber, Finset.mem_filter, Finset.mem_univ, true_and] at hb hb'
      exact h (hb.symm.trans hb')
  rw [Finset.sum_congr rfl (fun a' _ => card_fiber_eq π hπ j a' a), Finset.sum_const,
    Finset.card_univ, smul_eq_mul] at h_sum
  rw [mul_comm]
  exact h_sum

/-- Decimation intertwines the Haar averages of adjacent levels. -/
lemma fiberSum_avg (hπ : ∀ j, Function.Surjective (π j)) (j : ℕ) (f : Fn G (j + 1)) :
    fiberSum π j (avg G (j + 1) f) = avg G j (fiberSum π j f) := by
  ext a
  simp only [fiberSum_apply, avg_apply, Finset.sum_const, nsmul_eq_mul]
  rw [sum_fibers π j f]
  have hmul : ((fiber π j a).card : ℂ) * (Fintype.card (G j) : ℂ) =
      (Fintype.card (G (j + 1)) : ℂ) := by
    exact_mod_cast card_fiber_mul π hπ j a
  have h1 := card_ne_zero G (j + 1)
  have hc : ((fiber π j a).card : ℂ) ≠ 0 := by
    intro h
    apply h1
    rw [← hmul, h, zero_mul]
  rw [← hmul, mul_inv, ← mul_assoc, ← mul_assoc, mul_inv_cancel₀ hc, one_mul]

/-! ## 5. `PropertyA`, `PropertyB`, `PropertyC` for every tower -/

variable (G) in
theorem tower_PropertyA (w : ℂ) (lam : ℝ) (h0 : 0 ≤ lam) (h1 : lam < 1) :
    PropertyA (Fn G) (lazy G lam) (avg G) (totalMass G w) (q0 G) where
  operator_tendsto j := lazy_iterate_tendsto_delta G lam h0 h1 j 0
  observable_bound j := ⟨‖w‖ * Fintype.card (G j), by positivity, norm_totalMass_le G w j⟩

variable (G) in
theorem tower_PropertyB (w : ℂ) :
    PropertyB (Fn G) (fun _ => w) (avg G) (totalMass G w) (q0 G) where
  smear_eval j := (totalMass_delta G w j 0).symm
  factors j := (totalMass_avg G w j (q0 G j)).symm

/-- `PropertyC` for every tower (a `def`: it carries the decimation maps). -/
def tower_PropertyC (hπ : ∀ j, Function.Surjective (π j)) (w : ℂ) : PropertyC (Fn G) (avg G) (totalMass G w) (q0 G) where
  ρ := fiberSum π
  proj_intertwines j f := fiberSum_avg π hπ j f
  state_compatible j := by
    show fiberSum π j (delta G (j + 1) 0) = delta G j 0
    rw [fiberSum_delta, map_zero]
  functional_compatible j f := totalMass_fiberSum π w j f

end AdelicPlace3Unification.FiniteTower

namespace AdelicPlace3Unification.PadicTree

open AdelicPlace3Unification.FiniteTower

section Local

variable (p : ℕ) [hp : Fact (Nat.Prime p)]

instance padicPowNeZero (j : ℕ) : NeZero (p ^ j) := ⟨pow_ne_zero j hp.out.ne_zero⟩

/-- Level `j` of the `p`-ary tree: the `p ^ j` vertices `ZMod (p ^ j)`. -/
abbrev Level (j : ℕ) : Type := ZMod (p ^ j)

/-- Canonical projection `ZMod (p ^ (j + 1)) →+* ZMod (p ^ j)` (drop the last `p`-adic digit). -/
def projMod (j : ℕ) : ZMod (p ^ (j + 1)) →+* ZMod (p ^ j) :=
  ZMod.castHom (pow_dvd_pow p (Nat.le_succ j)) (ZMod (p ^ j))

lemma projMod_surjective (j : ℕ) : Function.Surjective (projMod p j) :=
  ZMod.castHom_surjective _

/-- `projMod` as an additive homomorphism between tree levels. -/
def πTree (j : ℕ) : Level p (j + 1) →+ Level p j where
  toFun := projMod p j
  map_zero' := map_zero _
  map_add' := map_add _

lemma πTree_surjective (j : ℕ) : Function.Surjective (πTree p j) := projMod_surjective p j

/-- Every vertex has exactly `p` children. -/
lemma card_children (j : ℕ) (a : Level p j) : (fiber (πTree p) j a).card = p := by
  have h := card_fiber_mul (πTree p) (πTree_surjective p) j a
  simp only [Level, ZMod.card, pow_succ] at h
  exact Nat.eq_of_mul_eq_mul_right (pow_pos hp.out.pos j) (by rw [h, mul_comm])

/-- **`PropertyA` on the `p`-adic tree** (lazy walk with rate `λ ∈ [0, 1)`, weight `w`). -/
theorem tree_PropertyA (w : ℂ) (lam : ℝ) (h0 : 0 ≤ lam) (h1 : lam < 1) :
    PropertyA (Fn (Level p)) (lazy (Level p) lam) (avg (Level p)) (totalMass (Level p) w)
      (q0 (Level p)) :=
  tower_PropertyA (Level p) w lam h0 h1

/-- **`PropertyB` on the `p`-adic tree** (`smear3 j = w` for every `j`). -/
theorem tree_PropertyB (w : ℂ) :
    PropertyB (Fn (Level p)) (fun _ => w) (avg (Level p)) (totalMass (Level p) w)
      (q0 (Level p)) :=
  tower_PropertyB (Level p) w

/-- **`PropertyC` on the `p`-adic tree**: decimation sums over the `p` children. -/
def tree_PropertyC (w : ℂ) :
    PropertyC (Fn (Level p)) (avg (Level p)) (totalMass (Level p) w) (q0 (Level p)) :=
  tower_PropertyC (πTree p) (πTree_surjective p) w

/-- The geometric bound `‖P^n q - Pr q‖ ≤ λ ^ n`, uniform in the depth `j`. -/
theorem tree_iterate_bound (lam : ℝ) (h0 : 0 ≤ lam) (j n : ℕ) :
    ‖(lazy (Level p) lam j ^ n) (q0 (Level p) j) - avg (Level p) j (q0 (Level p) j)‖ ≤
      lam ^ n :=
  norm_lazy_pow_delta_sub (Level p) lam h0 j n 0

theorem tree_observable_convergence (w : ℂ) (lam : ℝ) (h0 : 0 ≤ lam) (h1 : lam < 1) (j : ℕ) :
    Tendsto (fun n : ℕ => totalMass (Level p) w j ((lazy (Level p) lam j ^ n) (q0 (Level p) j)))
      atTop (nhds w) :=
  property_AB_imply_observable_convergence (Fn (Level p)) (tree_PropertyA p w lam h0 h1)
    (tree_PropertyB p w) j

theorem tree_rg_invariance (w : ℂ) (j d : ℕ) :
    w = totalMass (Level p) w j (avg (Level p) j (q0 (Level p) j)) :=
  property_BC_imply_rg_invariance (Fn (Level p)) (tree_PropertyB p w) (tree_PropertyC p w) j d

end Local

/-! ## Specializations `p = 3` and `p = 7` -/

instance fact_prime_three : Fact (Nat.Prime 3) := ⟨Nat.prime_three⟩
lemma prime_seven : Nat.Prime 7 := by norm_num

instance fact_prime_seven : Fact (Nat.Prime 7) := ⟨prime_seven⟩

/-- Canonical rate `λ_p = 1 / p`. -/
def rate (p : ℕ) : ℝ := (p : ℝ)⁻¹

lemma rate_bounds {p : ℕ} (hp : Nat.Prime p) : 0 ≤ rate p ∧ rate p < 1 := by
  have h : (1 : ℝ) < p := by exact_mod_cast hp.one_lt
  exact ⟨inv_nonneg.mpr (by linarith), inv_lt_one_of_one_lt₀ h⟩

theorem tree3_iterate_bound (j n : ℕ) :
    ‖(lazy (Level 3) (1 / 2) j ^ n) (q0 (Level 3) j) - avg (Level 3) j (q0 (Level 3) j)‖ ≤
      (1 / 2 : ℝ) ^ n :=
  tree_iterate_bound 3 (1 / 2) (by norm_num) j n

theorem tree7_iterate_bound (j n : ℕ) :
    ‖(lazy (Level 7) (1 / 2) j ^ n) (q0 (Level 7) j) - avg (Level 7) j (q0 (Level 7) j)‖ ≤
      (1 / 2 : ℝ) ^ n :=
  tree_iterate_bound 7 (1 / 2) (by norm_num) j n

theorem tree3_observable_convergence (j : ℕ) :
    Tendsto (fun n : ℕ =>
      totalMass (Level 3) 1 j ((lazy (Level 3) (rate 3) j ^ n) (q0 (Level 3) j)))
      atTop (nhds 1) :=
  tree_observable_convergence 3 1 (rate 3) (rate_bounds Nat.prime_three).1
    (rate_bounds Nat.prime_three).2 j

theorem tree7_observable_convergence (j : ℕ) :
    Tendsto (fun n : ℕ =>
      totalMass (Level 7) 1 j ((lazy (Level 7) (rate 7) j ^ n) (q0 (Level 7) j)))
      atTop (nhds 1) :=
  tree_observable_convergence 7 1 (rate 7) (rate_bounds prime_seven).1
    (rate_bounds prime_seven).2 j

theorem tree3_rg_invariance (j d : ℕ) :
    (1 : ℂ) = totalMass (Level 3) 1 j (avg (Level 3) j (q0 (Level 3) j)) :=
  tree_rg_invariance 3 1 j d

theorem tree7_rg_invariance (j d : ℕ) :
    (1 : ℂ) = totalMass (Level 7) 1 j (avg (Level 7) j (q0 (Level 7) j)) :=
  tree_rg_invariance 7 1 j d

/-! ## Finite Euler product over a finite set `S` of primes -/

section EulerProduct

/-- `Φ^{(p)}_k((P^{(p)}_k)^n q^{(p)}_k)` with rate `lam p` and weight `w p` for prime `p`,
and `1` otherwise (so that `Finset.prod` needs no subtype). -/
def dynObs (lam : ℕ → ℝ) (w : ℕ → ℂ) (p k n : ℕ) : ℂ :=
  if hp : Nat.Prime p then
    haveI : Fact (Nat.Prime p) := ⟨hp⟩
    totalMass (Level p) (w p) k ((lazy (Level p) (lam p) k ^ n) (q0 (Level p) k))
  else 1

/-- Restricted smear over `S` at depth `j + d` and time `n`. -/
def eulerSmear (lam : ℕ → ℝ) (w : ℕ → ℂ) (S : Finset ℕ) (j d n : ℕ) : ℂ :=
  ∏ p ∈ S, dynObs lam w p (j + d) n

lemma dynObs_tendsto (lam : ℕ → ℝ) (w : ℕ → ℂ) {p : ℕ} (hp : Nat.Prime p)
    (h0 : 0 ≤ lam p) (h1 : lam p < 1) (k : ℕ) :
    Tendsto (fun n => dynObs lam w p k n) atTop (nhds (w p)) := by
  haveI : Fact (Nat.Prime p) := ⟨hp⟩
  simp only [dynObs, dif_pos hp]
  exact tree_observable_convergence p (w p) (lam p) h0 h1 k

/-- **Finite Euler product reduction.** Hypothesis 3 of
`combined_adelic_stationary_rg_reduction` is proved here (not assumed): the active place `p₀`
converges by Properties A and B, the spectator places by `tendsto_finset_prod`. -/
theorem euler_combined_reduction (lam : ℕ → ℝ) (w : ℕ → ℂ) (S : Finset ℕ)
    (hS : ∀ p ∈ S, Nat.Prime p) (hlam : ∀ p ∈ S, 0 ≤ lam p ∧ lam p < 1)
    {p₀ : ℕ} (hp₀ : p₀ ∈ S) (j d : ℕ) :
    Tendsto (eulerSmear lam w S j d) atTop (nhds (∏ p ∈ S, w p)) := by
  have hp₀' : Nat.Prime p₀ := hS p₀ hp₀
  haveI : Fact (Nat.Prime p₀) := ⟨hp₀'⟩
  have hfactor : eulerSmear lam w S j d =
      fun n => dynObs lam w p₀ (j + d) n * ∏ p ∈ S.erase p₀, dynObs lam w p (j + d) n := by
    funext n
    exact (Finset.mul_prod_erase S (fun p => dynObs lam w p (j + d) n) hp₀).symm
  have h_active := dynObs_tendsto lam w hp₀' (hlam p₀ hp₀).1 (hlam p₀ hp₀).2 (j + d)
  have h_spec : Tendsto (fun n => ∏ p ∈ S.erase p₀, dynObs lam w p (j + d) n) atTop
      (nhds (∏ p ∈ S.erase p₀, w p)) :=
    tendsto_finset_prod _ fun p hp => dynObs_tendsto lam w (hS p (Finset.mem_of_mem_erase hp))
      (hlam p (Finset.mem_of_mem_erase hp)).1 (hlam p (Finset.mem_of_mem_erase hp)).2 (j + d)
  have h_hyp3 : Tendsto (eulerSmear lam w S j d) atTop
      (nhds ((fun _ : ℕ => w p₀) (j + d) * ∏ p ∈ S.erase p₀, w p)) := by
    rw [hfactor]
    exact h_active.mul h_spec
  have h_red := combined_adelic_stationary_rg_reduction (Fn (Level p₀))
    (eulerSmear lam w S j d) (fun _ => w p₀) (∏ p ∈ S.erase p₀, w p)
    (tree_PropertyB p₀ (w p₀)) (tree_PropertyC p₀ (w p₀)) j d h_hyp3
  have h_stat : totalMass (Level p₀) (w p₀) j (avg (Level p₀) j (q0 (Level p₀) j)) = w p₀ := by
    rw [totalMass_avg]
    exact totalMass_delta (Level p₀) (w p₀) j 0
  rw [h_stat, Finset.mul_prod_erase S w hp₀] at h_red
  exact h_red

lemma primes_3_7 : ∀ p ∈ ({3, 7} : Finset ℕ), Nat.Prime p := by
  intro p hp
  simp only [Finset.mem_insert, Finset.mem_singleton] at hp
  rcases hp with rfl | rfl <;> norm_num

/-- The notes' two-place `{3, 7}` coupling (rates `1/3`, `1/7`, unit weights): limit `1`. -/
theorem euler_3_7_unweighted (j d : ℕ) :
    Tendsto (eulerSmear rate (fun _ => 1) {3, 7} j d) atTop (nhds 1) := by
  have h := euler_combined_reduction rate (fun _ => (1 : ℂ)) {3, 7} primes_3_7
    (fun p hp => rate_bounds (primes_3_7 p hp)) (p₀ := 3) (by simp) j d
  simpa using h

/-- Local zeta factor `(1 - p ^ (-s))⁻¹`, natural exponent `s`. -/
def zetaFactor (s p : ℕ) : ℂ := (1 - ((p : ℂ) ^ s)⁻¹)⁻¹

lemma zetaFactor_prod_3_7 : ∏ p ∈ ({3, 7} : Finset ℕ), zetaFactor 2 p = 147 / 128 := by
  rw [Finset.prod_pair (by norm_num)]
  simp only [zetaFactor]
  norm_num

/-- With weights `w p = (1 - p⁻²)⁻¹` the limit is the finite product
`(9/8)·(49/48) = 147/128`. This is a statement about two chosen constants, not about `ζ(2)`. -/
theorem euler_3_7_zeta2 (j d : ℕ) :
    Tendsto (eulerSmear rate (zetaFactor 2) {3, 7} j d) atTop (nhds (147 / 128)) := by
  have h := euler_combined_reduction rate (zetaFactor 2) {3, 7} primes_3_7
    (fun p hp => rate_bounds (primes_3_7 p hp)) (p₀ := 3) (by simp) j d
  rwa [zetaFactor_prod_3_7] at h

end EulerProduct

/-! ## Two-place tensor family on `ZMod (p ^ j) × ZMod (r ^ j)` -/

section Pair

variable (p r : ℕ) [Fact (Nat.Prime p)] [Fact (Nat.Prime r)]

/-- Level `j` of the two-place tower. Functions on it are `V^{(p)}_j ⊗ V^{(r)}_j`. -/
abbrev PairLevel (j : ℕ) : Type := ZMod (p ^ j) × ZMod (r ^ j)

def πPair (j : ℕ) : PairLevel p r (j + 1) →+ PairLevel p r j where
  toFun ab := (projMod p j ab.1, projMod r j ab.2)
  map_zero' := by simp
  map_add' a b := by simp

lemma πPair_surjective (j : ℕ) : Function.Surjective (πPair p r j) := by
  rintro ⟨a, b⟩
  obtain ⟨a', rfl⟩ := projMod_surjective p j a
  obtain ⟨b', rfl⟩ := projMod_surjective r j b
  exact ⟨(a', b'), rfl⟩

/-- Pure tensor `(x ⊗ y)(a, b) = x a * y b`. -/
def pureTensor (j : ℕ) (x : Fn (Level p) j) (y : Fn (Level r) j) : Fn (PairLevel p r) j :=
  fun ab => x ab.1 * y ab.2

lemma pureTensor_apply (j : ℕ) (x : Fn (Level p) j) (y : Fn (Level r) j)
    (ab : PairLevel p r j) : pureTensor p r j x y ab = x ab.1 * y ab.2 := rfl

lemma sum_mul_sum_eq {α β : Type*} [Fintype α] [Fintype β] (x : α → ℂ) (y : β → ℂ) :
    (∑ a, x a) * (∑ b, y b) = ∑ a, ∑ b, x a * y b := by
  rw [Finset.sum_mul]
  simp_rw [Finset.mul_sum]

/-- Kronecker product of two linear maps. -/
def tensorEndo (j : ℕ) (A : Fn (Level p) j →ₗ[ℂ] Fn (Level p) j)
    (B : Fn (Level r) j →ₗ[ℂ] Fn (Level r) j) :
    Fn (PairLevel p r) j →ₗ[ℂ] Fn (PairLevel p r) j where
  toFun f ab := ∑ a', ∑ b', A (delta (Level p) j a') ab.1 * B (delta (Level r) j b') ab.2 *
    f (a', b')
  map_add' f g := by
    ext ab
    simp only [Pi.add_apply, mul_add, Finset.sum_add_distrib]
  map_smul' c f := by
    ext ab
    simp only [Pi.smul_apply, smul_eq_mul, RingHom.id_apply, Finset.mul_sum]
    exact Finset.sum_congr rfl fun a' _ => Finset.sum_congr rfl fun b' _ => by ring

lemma tensorEndo_apply (j : ℕ) (A : Fn (Level p) j →ₗ[ℂ] Fn (Level p) j)
    (B : Fn (Level r) j →ₗ[ℂ] Fn (Level r) j) (f : Fn (PairLevel p r) j)
    (ab : PairLevel p r j) :
    tensorEndo p r j A B f ab = ∑ a', ∑ b', A (delta (Level p) j a') ab.1 *
      B (delta (Level r) j b') ab.2 * f (a', b') := rfl

/-- `(A ⊗ B)(x ⊗ y) = (A x) ⊗ (B y)`. -/
lemma tensorEndo_pureTensor (j : ℕ) (A : Fn (Level p) j →ₗ[ℂ] Fn (Level p) j)
    (B : Fn (Level r) j →ₗ[ℂ] Fn (Level r) j) (x : Fn (Level p) j) (y : Fn (Level r) j) :
    tensorEndo p r j A B (pureTensor p r j x y) = pureTensor p r j (A x) (B y) := by
  ext ⟨a, b⟩
  simp only [tensorEndo_apply, pureTensor_apply]
  rw [apply_eq_sum_delta (Level p) j A x a, apply_eq_sum_delta (Level r) j B y b,
    Finset.sum_mul]
  refine Finset.sum_congr rfl fun a' _ => ?_
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl fun b' _ => ?_
  ring

lemma tensorEndo_pow_pureTensor (j n : ℕ) (A : Fn (Level p) j →ₗ[ℂ] Fn (Level p) j)
    (B : Fn (Level r) j →ₗ[ℂ] Fn (Level r) j) (x : Fn (Level p) j) (y : Fn (Level r) j) :
    (tensorEndo p r j A B ^ n) (pureTensor p r j x y) =
      pureTensor p r j ((A ^ n) x) ((B ^ n) y) := by
  induction n with
  | zero => simp
  | succ k ih =>
    rw [pow_succ' (tensorEndo p r j A B) k, LinearMap.mul_apply, ih, tensorEndo_pureTensor]
    simp only [pow_succ', LinearMap.mul_apply]

lemma avg_pureTensor (j : ℕ) (x : Fn (Level p) j) (y : Fn (Level r) j) :
    avg (PairLevel p r) j (pureTensor p r j x y) =
      pureTensor p r j (avg (Level p) j x) (avg (Level r) j y) := by
  ext ⟨a, b⟩
  simp only [avg_apply, pureTensor_apply, Fintype.card_prod, Nat.cast_mul,
    Fintype.sum_prod_type]
  rw [← sum_mul_sum_eq]
  ring

/-- The product Haar average is the Kronecker product of the local Haar averages. -/
lemma tensorEndo_avg_avg (j : ℕ) :
    tensorEndo p r j (avg (Level p) j) (avg (Level r) j) = avg (PairLevel p r) j := by
  apply LinearMap.ext
  intro f
  ext ⟨a, b⟩
  simp only [tensorEndo_apply, avg_delta_apply, avg_apply, sum_delta, mul_one,
    Fintype.card_prod, Nat.cast_mul, Fintype.sum_prod_type, Finset.mul_sum]
  refine Finset.sum_congr rfl fun a' _ => Finset.sum_congr rfl fun b' _ => ?_
  ring

lemma delta_pair (j : ℕ) (a₀ : ZMod (p ^ j)) (b₀ : ZMod (r ^ j)) :
    delta (PairLevel p r) j (a₀, b₀) =
      pureTensor p r j (delta (Level p) j a₀) (delta (Level r) j b₀) := by
  ext ⟨a, b⟩
  simp only [delta_apply, pureTensor_apply, Prod.mk.injEq]
  by_cases ha : a = a₀ <;> by_cases hb : b = b₀ <;> simp [ha, hb]

/-- Weighted total mass factorizes on pure tensors. -/
lemma totalMass_pureTensor (wp wr : ℂ) (j : ℕ) (x : Fn (Level p) j) (y : Fn (Level r) j) :
    totalMass (PairLevel p r) (wp * wr) j (pureTensor p r j x y) =
      totalMass (Level p) wp j x * totalMass (Level r) wr j y := by
  simp only [totalMass_apply, pureTensor_apply, Fintype.sum_prod_type]
  rw [← sum_mul_sum_eq]
  ring

lemma norm_pureTensor_le (j : ℕ) (x : Fn (Level p) j) (y : Fn (Level r) j) :
    ‖pureTensor p r j x y‖ ≤ ‖x‖ * ‖y‖ := by
  rw [pi_norm_le_iff_of_nonneg (mul_nonneg (norm_nonneg x) (norm_nonneg y))]
  rintro ⟨a, b⟩
  rw [pureTensor_apply, norm_mul]
  exact mul_le_mul (norm_le_pi_norm x a) (norm_le_pi_norm y b) (norm_nonneg _) (norm_nonneg _)

lemma norm_pureTensor_sub_le (j : ℕ) (x x₀ : Fn (Level p) j) (y y₀ : Fn (Level r) j) :
    ‖pureTensor p r j x y - pureTensor p r j x₀ y₀‖ ≤ ‖x - x₀‖ * ‖y‖ + ‖x₀‖ * ‖y - y₀‖ := by
  have hsplit : pureTensor p r j x y - pureTensor p r j x₀ y₀ =
      pureTensor p r j (x - x₀) y + pureTensor p r j x₀ (y - y₀) := by
    ext ab
    simp only [Pi.sub_apply, Pi.add_apply, pureTensor_apply]
    ring
  rw [hsplit]
  exact (norm_add_le _ _).trans
    (add_le_add (norm_pureTensor_le p r j _ _) (norm_pureTensor_le p r j _ _))

/-- Bound at a point mass `δ_(a, b)`: `‖(P_p ⊗ P_r)^n δ - Pr δ‖ ≤ λ_p ^ n + λ_r ^ n`. -/
lemma pair_site_bound (lp lr : ℝ) (hp0 : 0 ≤ lp) (hp1 : lp ≤ 1) (hr0 : 0 ≤ lr) (hr1 : lr ≤ 1)
    (j n : ℕ) (a : ZMod (p ^ j)) (b : ZMod (r ^ j)) :
    ‖(tensorEndo p r j (lazy (Level p) lp j) (lazy (Level r) lr j) ^ n)
        (delta (PairLevel p r) j (a, b)) - avg (PairLevel p r) j (delta (PairLevel p r) j (a, b))‖
      ≤ lp ^ n + lr ^ n := by
  rw [delta_pair, tensorEndo_pow_pureTensor, avg_pureTensor]
  refine (norm_pureTensor_sub_le p r j _ _ _ _).trans ?_
  have hp_err := norm_lazy_pow_delta_sub (Level p) lp hp0 j n a
  have hr_err := norm_lazy_pow_delta_sub (Level r) lr hr0 j n b
  have hr_norm : ‖(lazy (Level r) lr j ^ n) (delta (Level r) j b)‖ ≤ 1 :=
    (lazy_pow_norm_le (Level r) lr hr0 hr1 j n _).trans (norm_delta_le (Level r) j b)
  have hp_avg : ‖avg (Level p) j (delta (Level p) j a)‖ ≤ 1 :=
    (norm_avg_le (Level p) j _).trans (norm_delta_le (Level p) j a)
  calc _ ≤ lp ^ n * 1 + 1 * lr ^ n :=
        add_le_add (mul_le_mul hp_err hr_norm (norm_nonneg _) (pow_nonneg hp0 n))
          (mul_le_mul hp_avg hr_err (norm_nonneg _) zero_le_one)
    _ = lp ^ n + lr ^ n := by ring

/-- The two-place evolution `P_j = P^{(p)}_j ⊗ P^{(r)}_j`. -/
def pairWalk (lp lr : ℝ) (j : ℕ) : Fn (PairLevel p r) j →ₗ[ℂ] Fn (PairLevel p r) j :=
  tensorEndo p r j (lazy (Level p) lp j) (lazy (Level r) lr j)

lemma tendsto_pow_add_pow {lp lr : ℝ} (hp0 : 0 ≤ lp) (hp1 : lp < 1) (hr0 : 0 ≤ lr)
    (hr1 : lr < 1) : Tendsto (fun n : ℕ => lp ^ n + lr ^ n) atTop (nhds 0) := by
  simpa using (tendsto_pow_atTop_nhds_zero_of_lt_one hp0 hp1).add
    (tendsto_pow_atTop_nhds_zero_of_lt_one hr0 hr1)

/-- **`PropertyA` for the product prepared state `δ_(0,0) = δ₀ ⊗ δ₀`.** -/
theorem pair_PropertyA (w : ℂ) (lp lr : ℝ) (hp0 : 0 ≤ lp) (hp1 : lp < 1) (hr0 : 0 ≤ lr)
    (hr1 : lr < 1) :
    PropertyA (Fn (PairLevel p r)) (pairWalk p r lp lr) (avg (PairLevel p r))
      (totalMass (PairLevel p r) w) (q0 (PairLevel p r)) where
  operator_tendsto j := squeeze_zero (fun n => norm_nonneg _)
    (fun n => pair_site_bound p r lp lr hp0 hp1.le hr0 hr1.le j n 0 0)
    (tendsto_pow_add_pow hp0 hp1 hr0 hr1)
  observable_bound j :=
    ⟨‖w‖ * Fintype.card (PairLevel p r j), by positivity, norm_totalMass_le _ w j⟩

theorem pair_PropertyB (w : ℂ) :
    PropertyB (Fn (PairLevel p r)) (fun _ => w) (avg (PairLevel p r))
      (totalMass (PairLevel p r) w) (q0 (PairLevel p r)) :=
  tower_PropertyB (PairLevel p r) w

def pair_PropertyC (w : ℂ) :
    PropertyC (Fn (PairLevel p r)) (avg (PairLevel p r)) (totalMass (PairLevel p r) w)
      (q0 (PairLevel p r)) :=
  tower_PropertyC (πPair p r) (πPair_surjective p r) w

/-- On the product state the two-place observable is the product of the one-place observables
(weights `w_p * w_r`): the tensor family reproduces the two-place product of Notes 9. -/
theorem pair_obs_factorization (wp wr : ℂ) (lp lr : ℝ) (j n : ℕ) :
    totalMass (PairLevel p r) (wp * wr) j ((pairWalk p r lp lr j ^ n) (q0 (PairLevel p r) j)) =
      totalMass (Level p) wp j ((lazy (Level p) lp j ^ n) (q0 (Level p) j)) *
      totalMass (Level r) wr j ((lazy (Level r) lr j ^ n) (q0 (Level r) j)) := by
  rw [show q0 (PairLevel p r) j = pureTensor p r j (q0 (Level p) j) (q0 (Level r) j) from
    delta_pair p r j 0 0, pairWalk, tensorEndo_pow_pureTensor, totalMass_pureTensor]

/-! ### A correlated (non-product) prepared state -/

lemma level_zero_eq {m : ℕ} [Fact (Nat.Prime m)] (x : ZMod (m ^ 0)) : x = 0 := by
  have h : x.val < m ^ 0 := ZMod.val_lt x
  rw [pow_zero, Nat.lt_one_iff] at h
  rw [← ZMod.natCast_zmod_val x, h, Nat.cast_zero]

lemma one_ne_zero_level {m : ℕ} [hm : Fact (Nat.Prime m)] (k : ℕ) :
    (1 : ZMod (m ^ (k + 1))) ≠ 0 := by
  haveI : Fact (1 < m ^ (k + 1)) := ⟨Nat.one_lt_pow (by omega) hm.out.one_lt⟩
  exact one_ne_zero

/-- `q_0 = δ_(0,0)` and `q_(j+1) = ½ δ_(0,0) + ½ δ_(1,1)` (the notes' `entangledPreparedState`). -/
def corrState : ∀ j, Fn (PairLevel p r) j
  | 0 => delta (PairLevel p r) 0 (0, 0)
  | j + 1 => (1 / 2 : ℂ) • delta (PairLevel p r) (j + 1) (0, 0) +
      (1 / 2 : ℂ) • delta (PairLevel p r) (j + 1) (1, 1)

/-- For `j ≥ 1` the state is not a pure tensor `x ⊗ y`. -/
theorem corrState_not_pure (j : ℕ) (hj : 1 ≤ j) :
    ¬ ∃ (x : Fn (Level p) j) (y : Fn (Level r) j), corrState p r j = pureTensor p r j x y := by
  obtain ⟨k, rfl⟩ : ∃ k, j = k + 1 := ⟨j - 1, by omega⟩
  rintro ⟨x, y, h⟩
  have hp1 : (1 : ZMod (p ^ (k + 1))) ≠ 0 := one_ne_zero_level k
  have hr1 : (1 : ZMod (r ^ (k + 1))) ≠ 0 := one_ne_zero_level k
  have hval : ∀ ab : PairLevel p r (k + 1), corrState p r (k + 1) ab =
      (1 / 2 : ℂ) * delta (PairLevel p r) (k + 1) (0, 0) ab +
      (1 / 2 : ℂ) * delta (PairLevel p r) (k + 1) (1, 1) ab := fun _ => rfl
  have n1 : ((0 : ZMod (p ^ (k + 1))), (0 : ZMod (r ^ (k + 1)))) ≠
      ((1 : ZMod (p ^ (k + 1))), (1 : ZMod (r ^ (k + 1)))) :=
    fun h => hp1 (Prod.ext_iff.mp h).1.symm
  have n2 : ((1 : ZMod (p ^ (k + 1))), (1 : ZMod (r ^ (k + 1)))) ≠
      ((0 : ZMod (p ^ (k + 1))), (0 : ZMod (r ^ (k + 1)))) :=
    fun h => hp1 (Prod.ext_iff.mp h).1
  have n3 : ((0 : ZMod (p ^ (k + 1))), (1 : ZMod (r ^ (k + 1)))) ≠
      ((0 : ZMod (p ^ (k + 1))), (0 : ZMod (r ^ (k + 1)))) :=
    fun h => hr1 (Prod.ext_iff.mp h).2
  have n4 : ((0 : ZMod (p ^ (k + 1))), (1 : ZMod (r ^ (k + 1)))) ≠
      ((1 : ZMod (p ^ (k + 1))), (1 : ZMod (r ^ (k + 1)))) :=
    fun h => hp1 (Prod.ext_iff.mp h).1.symm
  have n5 : ((1 : ZMod (p ^ (k + 1))), (0 : ZMod (r ^ (k + 1)))) ≠
      ((0 : ZMod (p ^ (k + 1))), (0 : ZMod (r ^ (k + 1)))) :=
    fun h => hp1 (Prod.ext_iff.mp h).1
  have n6 : ((1 : ZMod (p ^ (k + 1))), (0 : ZMod (r ^ (k + 1)))) ≠
      ((1 : ZMod (p ^ (k + 1))), (1 : ZMod (r ^ (k + 1)))) :=
    fun h => hr1 (Prod.ext_iff.mp h).2.symm
  have v00 : corrState p r (k + 1) (0, 0) = 1 / 2 := by
    rw [hval, delta_apply, delta_apply, if_pos rfl, if_neg n1]
    ring
  have v11 : corrState p r (k + 1) (1, 1) = 1 / 2 := by
    rw [hval, delta_apply, delta_apply, if_neg n2, if_pos rfl]
    ring
  have v01 : corrState p r (k + 1) (0, 1) = 0 := by
    rw [hval, delta_apply, delta_apply, if_neg n3, if_neg n4]
    ring
  have v10 : corrState p r (k + 1) (1, 0) = 0 := by
    rw [hval, delta_apply, delta_apply, if_neg n5, if_neg n6]
    ring
  have e00 : x 0 * y 0 = 1 / 2 := by
    have := congrFun h (0, 0); rw [v00] at this; exact this.symm
  have e11 : x 1 * y 1 = 1 / 2 := by
    have := congrFun h (1, 1); rw [v11] at this; exact this.symm
  have e01 : x 0 * y 1 = 0 := by
    have := congrFun h (0, 1); rw [v01] at this; exact this.symm
  have e10 : x 1 * y 0 = 0 := by
    have := congrFun h (1, 0); rw [v10] at this; exact this.symm
  have key : (x 0 * y 0) * (x 1 * y 1) = (x 0 * y 1) * (x 1 * y 0) := by ring
  rw [e00, e11, e01, e10] at key
  norm_num at key

lemma totalMass_corrState (w : ℂ) (j : ℕ) :
    totalMass (PairLevel p r) w j (corrState p r j) = w := by
  cases j with
  | zero => exact totalMass_delta (PairLevel p r) w 0 (0, 0)
  | succ k =>
    show totalMass (PairLevel p r) w (k + 1) ((1 / 2 : ℂ) • delta (PairLevel p r) (k + 1) (0, 0) +
      (1 / 2 : ℂ) • delta (PairLevel p r) (k + 1) (1, 1)) = w
    rw [map_add, map_smul, map_smul, totalMass_delta, totalMass_delta]
    simp only [smul_eq_mul]
    ring

lemma fiberSum_corrState (j : ℕ) :
    fiberSum (πPair p r) j (corrState p r (j + 1)) = corrState p r j := by
  show fiberSum (πPair p r) j ((1 / 2 : ℂ) • delta (PairLevel p r) (j + 1) (0, 0) +
    (1 / 2 : ℂ) • delta (PairLevel p r) (j + 1) (1, 1)) = corrState p r j
  rw [map_add, map_smul, map_smul, fiberSum_delta, fiberSum_delta]
  have h00 : πPair p r j (0, 0) = (0, 0) := by
    show (projMod p j 0, projMod r j 0) = (0, 0)
    rw [map_zero, map_zero]
  rw [h00]
  cases j with
  | zero =>
    have h11 : πPair p r 0 (1, 1) = (0, 0) :=
      Prod.ext (level_zero_eq _) (level_zero_eq _)
    rw [h11, ← add_smul]
    have h : (1 / 2 : ℂ) + 1 / 2 = 1 := by norm_num
    rw [h, one_smul]
    rfl
  | succ k =>
    have h11 : πPair p r (k + 1) (1, 1) = (1, 1) := by
      show (projMod p (k + 1) 1, projMod r (k + 1) 1) = (1, 1)
      rw [map_one, map_one]
    rw [h11]
    rfl

lemma corr_bound (lp lr : ℝ) (hp0 : 0 ≤ lp) (hp1 : lp ≤ 1) (hr0 : 0 ≤ lr) (hr1 : lr ≤ 1)
    (j n : ℕ) :
    ‖(pairWalk p r lp lr j ^ n) (corrState p r j) - avg (PairLevel p r) j (corrState p r j)‖ ≤
      lp ^ n + lr ^ n := by
  cases j with
  | zero => exact pair_site_bound p r lp lr hp0 hp1 hr0 hr1 0 n 0 0
  | succ k =>
    set T := pairWalk p r lp lr (k + 1) ^ n
    set A := delta (PairLevel p r) (k + 1) (0, 0)
    set B := delta (PairLevel p r) (k + 1) (1, 1)
    show ‖T ((1 / 2 : ℂ) • A + (1 / 2 : ℂ) • B) -
      avg (PairLevel p r) (k + 1) ((1 / 2 : ℂ) • A + (1 / 2 : ℂ) • B)‖ ≤ lp ^ n + lr ^ n
    have hA : ‖T A - avg (PairLevel p r) (k + 1) A‖ ≤ lp ^ n + lr ^ n :=
      pair_site_bound p r lp lr hp0 hp1 hr0 hr1 (k + 1) n 0 0
    have hB : ‖T B - avg (PairLevel p r) (k + 1) B‖ ≤ lp ^ n + lr ^ n :=
      pair_site_bound p r lp lr hp0 hp1 hr0 hr1 (k + 1) n 1 1
    have hsplit : T ((1 / 2 : ℂ) • A + (1 / 2 : ℂ) • B) -
        avg (PairLevel p r) (k + 1) ((1 / 2 : ℂ) • A + (1 / 2 : ℂ) • B) =
        (1 / 2 : ℂ) • (T A - avg (PairLevel p r) (k + 1) A) +
        (1 / 2 : ℂ) • (T B - avg (PairLevel p r) (k + 1) B) := by
      simp only [map_add, map_smul, smul_sub]
      abel
    have hhalf : ‖(1 / 2 : ℂ)‖ = 1 / 2 := by norm_num
    rw [hsplit]
    calc _ ≤ ‖(1 / 2 : ℂ) • (T A - avg (PairLevel p r) (k + 1) A)‖ +
          ‖(1 / 2 : ℂ) • (T B - avg (PairLevel p r) (k + 1) B)‖ := norm_add_le _ _
      _ = 1 / 2 * ‖T A - avg (PairLevel p r) (k + 1) A‖ +
          1 / 2 * ‖T B - avg (PairLevel p r) (k + 1) B‖ := by
          rw [norm_smul, norm_smul, hhalf]
      _ ≤ 1 / 2 * (lp ^ n + lr ^ n) + 1 / 2 * (lp ^ n + lr ^ n) := by gcongr
      _ = lp ^ n + lr ^ n := by ring

theorem corr_PropertyA (w : ℂ) (lp lr : ℝ) (hp0 : 0 ≤ lp) (hp1 : lp < 1) (hr0 : 0 ≤ lr)
    (hr1 : lr < 1) :
    PropertyA (Fn (PairLevel p r)) (pairWalk p r lp lr) (avg (PairLevel p r))
      (totalMass (PairLevel p r) w) (corrState p r) where
  operator_tendsto j := squeeze_zero (fun n => norm_nonneg _)
    (fun n => corr_bound p r lp lr hp0 hp1.le hr0 hr1.le j n)
    (tendsto_pow_add_pow hp0 hp1 hr0 hr1)
  observable_bound j :=
    ⟨‖w‖ * Fintype.card (PairLevel p r j), by positivity, norm_totalMass_le _ w j⟩

theorem corr_PropertyB (w : ℂ) :
    PropertyB (Fn (PairLevel p r)) (fun _ => w) (avg (PairLevel p r))
      (totalMass (PairLevel p r) w) (corrState p r) where
  smear_eval j := (totalMass_corrState p r w j).symm
  factors j := (totalMass_avg (PairLevel p r) w j (corrState p r j)).symm

def corr_PropertyC (w : ℂ) :
    PropertyC (Fn (PairLevel p r)) (avg (PairLevel p r)) (totalMass (PairLevel p r) w)
      (corrState p r) where
  ρ := fiberSum (πPair p r)
  proj_intertwines j f := fiberSum_avg (πPair p r) (πPair_surjective p r) j f
  state_compatible j := fiberSum_corrState p r j
  functional_compatible j f := totalMass_fiberSum (πPair p r) w j f

end Pair

/-! ## The `(3, 7)` two-place instances -/

/-- Rates `1/3`, `1/7`: `‖P^n q - Pr q‖ ≤ 3⁻ⁿ + 7⁻ⁿ` for the correlated state. -/
theorem corr37_bound (j n : ℕ) :
    ‖(pairWalk 3 7 (rate 3) (rate 7) j ^ n) (corrState 3 7 j) -
        avg (PairLevel 3 7) j (corrState 3 7 j)‖ ≤ rate 3 ^ n + rate 7 ^ n :=
  corr_bound 3 7 (rate 3) (rate 7) (rate_bounds Nat.prime_three).1
    (rate_bounds Nat.prime_three).2.le (rate_bounds prime_seven).1
    (rate_bounds prime_seven).2.le j n

theorem corr37_observable_convergence (j : ℕ) :
    Tendsto (fun n : ℕ =>
      totalMass (PairLevel 3 7) 1 j ((pairWalk 3 7 (rate 3) (rate 7) j ^ n) (corrState 3 7 j)))
      atTop (nhds 1) :=
  property_AB_imply_observable_convergence (Fn (PairLevel 3 7))
    (corr_PropertyA 3 7 1 (rate 3) (rate 7) (rate_bounds Nat.prime_three).1
      (rate_bounds Nat.prime_three).2 (rate_bounds prime_seven).1 (rate_bounds prime_seven).2)
    (corr_PropertyB 3 7 1) j

theorem corr37_rg_invariance (j d : ℕ) :
    (1 : ℂ) = totalMass (PairLevel 3 7) 1 j (avg (PairLevel 3 7) j (corrState 3 7 j)) :=
  property_BC_imply_rg_invariance (Fn (PairLevel 3 7)) (corr_PropertyB 3 7 1)
    (corr_PropertyC 3 7 1) j d

end AdelicPlace3Unification.PadicTree


/-! # Part 5: Adelic-sum convergence for an explicit test family (a reduction of interface C2)

Interface C2 asks that `∑_v |⟨ω - cl(Z), ψ^{(v)}⟩_{𝔸_v}|²` converge. This part fixes the test
family and proves the convergence statement that the family supports, for local data that are
given abstractly.

* Test vector at a finite place `p`: `ψ_p = c_s(p) • q0`, where `q0` is the point-mass prepared
  state of `PadicTree` on `ZMod (p ^ j)` and `c_s(p) = zetaFactor s p - 1 = (p ^ s - 1)⁻¹`.
  The pairing of a local vector `x_p` with `ψ_p` is `c_s(p) * a p`, where `a p = x_p 0`.
* `adelic_sum_summable`: if `‖a p‖ ≤ M` for all `p`, then `∑_p ‖a p‖² · c_s(p)²` converges for
  every `s ≥ 1`.
* The weight must decay. `zetaFactor s p` itself tends to `1`, so weighting by `zetaFactor` alone
  gives a divergent sum whenever the pairings do not decay; the decaying weight is
  `zetaFactor s p - 1` (`zetaFactor_sub_one`).
* The archimedean place contributes one further finite term and does not affect convergence.

What this does not do: it does not construct the local data `a p` from a class `ω - cl(Z)` on the
Hodge manifold `ℳ`. That requires a map from `H^{2p}(ℳ)` to the local spaces (interface C5) and
Assumption (A) for `Z`. C2 therefore remains open; this part reduces it, for this test family,
to the existence of such a map with uniformly bounded local images. `PropertyC` (decimation
compatibility) gives level independence of the pairing at each place separately; it plays no
role in convergence over places.

Lemma names most likely to need adjustment to the pinned Mathlib: `pow_le_pow_left₀`,
`pow_le_pow_right₀`, `inv_anti₀`, `Real.summable_nat_pow_inv`, `Summable.of_nonneg_of_le`.
-/

namespace AdelicPlace3Unification.AdelicSum

open AdelicPlace3Unification.PadicTree

/-- The decaying weight `(p ^ s - 1)⁻¹ = zetaFactor s p - 1`. -/
def zetaWeight (s p : ℕ) : ℝ := ((p : ℝ) ^ s - 1)⁻¹

lemma two_le_pow {s p : ℕ} (hp : 2 ≤ p) (hs : 1 ≤ s) : (2 : ℝ) ≤ (p : ℝ) ^ s := by
  have hp' : (2 : ℝ) ≤ (p : ℝ) := by exact_mod_cast hp
  have h1 : (1 : ℝ) ≤ (p : ℝ) := le_trans (by norm_num) hp'
  calc (2 : ℝ) ≤ (p : ℝ) := hp'
    _ = (p : ℝ) ^ 1 := (pow_one _).symm
    _ ≤ (p : ℝ) ^ s := pow_le_pow_right₀ h1 hs

lemma zetaWeight_nonneg {s p : ℕ} (hp : 2 ≤ p) (hs : 1 ≤ s) : 0 ≤ zetaWeight s p := by
  have h := two_le_pow hp hs
  unfold zetaWeight
  exact inv_nonneg.mpr (by linarith)

/-- `(p ^ s - 1)⁻¹ ≤ 2 (p ^ s)⁻¹` once `p ^ s ≥ 2`. -/
lemma zetaWeight_le {s p : ℕ} (hp : 2 ≤ p) (hs : 1 ≤ s) :
    zetaWeight s p ≤ 2 * ((p : ℝ) ^ s)⁻¹ := by
  have h := two_le_pow hp hs
  have hpos : (0 : ℝ) < (p : ℝ) ^ s / 2 := by linarith
  have hle : (p : ℝ) ^ s / 2 ≤ (p : ℝ) ^ s - 1 := by linarith
  have h2 : 2 * ((p : ℝ) ^ s)⁻¹ = ((p : ℝ) ^ s / 2)⁻¹ := by
    rw [inv_div, div_eq_mul_inv]
  rw [h2]
  unfold zetaWeight
  exact inv_anti₀ hpos hle

/-- The weight is the local zeta factor minus one. -/
lemma zetaFactor_sub_one {s p : ℕ} (hp : 2 ≤ p) (hs : 1 ≤ s) :
    zetaFactor s p - 1 = ((zetaWeight s p : ℝ) : ℂ) := by
  have h := two_le_pow hp hs
  have ha : ((p : ℂ) ^ s) ≠ 0 := by
    have : ((p : ℝ) ^ s) ≠ 0 := by linarith
    exact_mod_cast this
  have hb : ((p : ℂ) ^ s) - 1 ≠ 0 := by
    have : ((p : ℝ) ^ s) - 1 ≠ 0 := by linarith
    exact_mod_cast this
  have hc : (1 : ℂ) - ((p : ℂ) ^ s)⁻¹ = ((p : ℂ) ^ s - 1) / (p : ℂ) ^ s := by
    rw [sub_div, div_self ha, one_div]
  simp only [zetaFactor, zetaWeight]
  push_cast
  rw [hc, inv_div, div_sub_one hb, show (p : ℂ) ^ s - ((p : ℂ) ^ s - 1) = 1 by ring, one_div]

/-- **Convergence over the finite places.** For any uniformly bounded family of local pairings
`a p` and any `s ≥ 1`, the sum over primes of `‖a p‖² · zetaWeight s p ²` converges. -/
theorem adelic_sum_summable (s : ℕ) (hs : 1 ≤ s) (a : ℕ → ℂ) (M : ℝ)
    (ha : ∀ n, ‖a n‖ ≤ M) :
    Summable (fun n : ℕ => if n.Prime then ‖a n‖ ^ 2 * zetaWeight s n ^ 2 else 0) := by
  have hM : 0 ≤ M := le_trans (norm_nonneg _) (ha 0)
  have hsum : Summable (fun n : ℕ => 4 * M ^ 2 * ((n : ℝ) ^ (2 * s))⁻¹) :=
    (Real.summable_nat_pow_inv.mpr (by omega)).mul_left (4 * M ^ 2)
  refine Summable.of_nonneg_of_le (fun n => ?_) (fun n => ?_) hsum
  · split_ifs with hn
    · exact mul_nonneg (sq_nonneg _) (sq_nonneg _)
    · exact le_refl 0
  · split_ifs with hn
    · have hp2 : 2 ≤ n := hn.two_le
      have hw0 := zetaWeight_nonneg hp2 hs
      have hw := zetaWeight_le hp2 hs
      have h1 : ‖a n‖ ^ 2 ≤ M ^ 2 := pow_le_pow_left₀ (norm_nonneg _) (ha n) 2
      have h2 : zetaWeight s n ^ 2 ≤ (2 * ((n : ℝ) ^ s)⁻¹) ^ 2 := pow_le_pow_left₀ hw0 hw 2
      have h3 : (2 * ((n : ℝ) ^ s)⁻¹) ^ 2 = 4 * ((n : ℝ) ^ (2 * s))⁻¹ := by
        rw [pow_mul']
        ring
      calc ‖a n‖ ^ 2 * zetaWeight s n ^ 2
          ≤ M ^ 2 * (2 * ((n : ℝ) ^ s)⁻¹) ^ 2 :=
            mul_le_mul h1 h2 (sq_nonneg _) (sq_nonneg _)
        _ = 4 * M ^ 2 * ((n : ℝ) ^ (2 * s))⁻¹ := by rw [h3]; ring
    · positivity

/-- **Reduction of C2 for this test family.** Given local data at the finite places with
uniformly bounded pairings against `q0`, and any value at the archimedean place, the full
adelic sum (archimedean term plus the convergent sum over primes) is a finite real number.
The hypothesis `ha` is exactly what a C5-type map from `ℳ` would have to supply. -/
theorem C2_reduction (s : ℕ) (hs : 1 ≤ s) (a : ℕ → ℂ) (aInf : ℂ) (M : ℝ)
    (ha : ∀ n, ‖a n‖ ≤ M) :
    ∃ S : ℝ, HasSum (fun n : ℕ => if n.Prime then ‖a n‖ ^ 2 * zetaWeight s n ^ 2 else 0)
      (S - ‖aInf‖ ^ 2) := by
  obtain ⟨T, hT⟩ := adelic_sum_summable s hs a M ha
  exact ⟨T + ‖aInf‖ ^ 2, by simpa using hT⟩

end AdelicPlace3Unification.AdelicSum

end
