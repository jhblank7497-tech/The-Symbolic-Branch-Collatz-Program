# CollatzWilsonCombined (v23) and AdelicPlace3Unification (v4): build check

Compiles `CollatzWilsonCombined.lean` (version v23, body SHA256
`7fb005e75886e2fe774b34edf1ceb194b8fa709de04a5e1925b782699657b440`) against Mathlib `v4.35.0`
(Lean `v4.35.0`) using the pre-built Mathlib cache, so Mathlib is not compiled from source.
It also compiles `AdelicPlace3Unification.lean` (version 4, with Part 5 `AdelicSum`). The two
files are built in separate steps, so an error in one does not hide the other; the logs are
`build-collatz.log` and `build-adelic.log`.

## Run it on GitHub

1. Create an empty repository and push this folder to it:
   ```
   git init && git add . && git commit -m "Build check"
   git branch -M main
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```
2. The workflow in `.github/workflows/build.yml` runs on the push. Open the repository's
   **Actions** tab; the full compiler output is attached to the run as the `build-log` artifact.

## Run it locally

With [elan](https://github.com/leanprover/elan) installed:
```
lake update            # resolves Mathlib v4.35.0 and writes lake-manifest.json
lake exe cache get     # downloads pre-built Mathlib
lake build
```

## What to expect

Neither file has been compiled. `AdelicPlace3Unification.lean` was originally written against an
older Mathlib (around v4.14), so it may report more renamed lemmas. Its Mathlib lemma names were written without a pinned Mathlib
version, so the first build is expected to report errors (mainly renamed or deprecated lemmas and
tactic steps that do not close). The log lists each error with its line number; those are the
fixes to make. A clean build with no `declaration uses 'sorry'` warnings is what certifies the file.

If many errors come from renamed lemmas, pinning an older Mathlib in `lakefile.toml` (and the
matching `lean-toolchain`) is an alternative to renaming.
